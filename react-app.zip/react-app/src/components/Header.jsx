import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useCart } from "../hooks/useCart.js";
import { useTheme } from "../hooks/useTheme.js";
import SearchBar from "./SearchBar.jsx";

export default function Header() {
  const { cartCount, wishlist, user, logout } = useCart();
  const { theme, toggleTheme } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const navLinks = [
    { label: "Home", path: "/" },
    { label: "Shop", path: "/products" },
    { label: "Cart", path: "/cart" },
    { label: "Wishlist", path: "/wishlist" },
  ];

  return (
    <header className="header">
      <div className="header-inner">
        <Link to="/" className="brand" onClick={() => setMenuOpen(false)}>
          <span className="brand-mark">N</span>
          Nova<span>Cart</span>
        </Link>

        <SearchBar />

        <nav className={`nav ${menuOpen ? "open" : ""}`}>
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `nav-link ${isActive ? "active" : ""}`
              }
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
              {link.path === "/cart" && cartCount > 0 && (
                <span className="badge">{cartCount}</span>
              )}
              {link.path === "/wishlist" && wishlist.length > 0 && (
                <span className="badge">{wishlist.length}</span>
              )}
            </NavLink>
          ))}

          {user ? (
            <button className="ghost-button" onClick={logout}>
              Logout
            </button>
          ) : (
            <button
              className="primary-button"
              onClick={() => {
                setMenuOpen(false);
                navigate("/login");
              }}
            >
              Login
            </button>
          )}
        </nav>

        <div className="header-actions">
          <button
            className="icon-button"
            onClick={toggleTheme}
            aria-label="Toggle dark mode"
          >
            {theme === "light" ? "🌙" : "☀️"}
          </button>

          <button
            className="icon-button menu-toggle"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Toggle navigation"
          >
            ☰
          </button>
        </div>
      </div>
    </header>
  );
}