import { Link } from "react-router-dom";
import { useCart } from "../hooks/useCart.js";

export default function ProductCard({ product }) {
  const { addToCart, toggleWishlist, wishlist } = useCart();
  const isWishlisted = wishlist.some((item) => item.id === product.id);

  return (
    <article className="product-card">
      <button
        className={`wishlist-button ${isWishlisted ? "active" : ""}`}
        onClick={() => toggleWishlist(product)}
        aria-label="Toggle wishlist"
      >
        {isWishlisted ? "♥" : "♡"}
      </button>

      <Link to={`/products/${product.id}`} className="product-image-link">
        <img src={product.thumbnail} alt={product.title} loading="lazy" />
      </Link>

      <div className="product-card-body">
        <span className="product-category">{product.category}</span>
        <Link to={`/products/${product.id}`} className="product-title">
          {product.title}
        </Link>

        <div className="product-meta">
          <span className="product-price">${product.price.toFixed(2)}</span>
          <span className="product-rating">★ {product.rating.toFixed(1)}</span>
        </div>

        <button className="primary-button full-width" onClick={() => addToCart(product)}>
          Add to Cart
        </button>
      </div>
    </article>
  );
}