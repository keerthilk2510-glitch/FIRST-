import { useNavigate } from "react-router-dom";
import { useProducts } from "../hooks/useProducts.js";

export default function SearchBar() {
  const { searchQuery, setSearchQuery } = useProducts();
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    navigate("/products");
  };

  return (
    <form className="search-bar" onSubmit={handleSubmit}>
      <input
        type="search"
        placeholder="Search products..."
        value={searchQuery}
        onChange={(event) => setSearchQuery(event.target.value)}
        aria-label="Search products"
      />
      <button type="submit">Search</button>
    </form>
  );
}