import { useProducts } from "../hooks/useProducts.js";

export default function SortSelect() {
  const { sortOption, setSortOption, setCurrentPage } = useProducts();

  return (
    <select
      className="sort-select"
      value={sortOption}
      onChange={(event) => {
        setSortOption(event.target.value);
        setCurrentPage(1);
      }}
      aria-label="Sort products"
    >
      <option value="default">Sort: Featured</option>
      <option value="price-low-high">Price: Low to High</option>
      <option value="price-high-low">Price: High to Low</option>
      <option value="rating-high-low">Rating: High to Low</option>
    </select>
  );
}