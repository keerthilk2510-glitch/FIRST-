export default function ErrorState({ message, onRetry }) {
  return (
    <div className="error-state">
      <h3>Something went wrong</h3>
      <p>{message}</p>
      {onRetry && (
        <button className="primary-button" onClick={onRetry}>
          Try Again
        </button>
      )}
    </div>
  );
}