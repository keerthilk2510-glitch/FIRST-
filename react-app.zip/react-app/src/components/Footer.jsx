import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div>
          <h4>NovaCart</h4>
          <p>A modern React shopping experience built with Context API.</p>
        </div>

        <div className="footer-links">
          <Link to="/products">Shop</Link>
          <Link to="/cart">Cart</Link>
          <Link to="/wishlist">Wishlist</Link>
          <Link to="/login">Login</Link>
        </div>
      </div>

      <p className="copyright">© {new Date().getFullYear()} NovaCart. All rights reserved.</p>
    </footer>
  );
}