import { useProducts } from "../hooks/useProducts.js";

export default function CategoryFilter() {
  const { categories, selectedCategory, setSelectedCategory, setCurrentPage } =
    useProducts();

  return (
    <div className="filter-row">
      <button
        className={`chip ${selectedCategory === "all" ? "active" : ""}`}
        onClick={() => {
          setSelectedCategory("all");
          setCurrentPage(1);
        }}
      >
        All
      </button>

      {categories.map((category) => (
        <button
          key={category.slug}
          className={`chip ${selectedCategory === category.slug ? "active" : ""}`}
          onClick={() => {
            setSelectedCategory(category.slug);
            setCurrentPage(1);
          }}
        >
          {category.name}
        </button>
      ))}
    </div>
  );
}