import ProductCard from "./ProductCard.jsx";
import EmptyState from "./EmptyState.jsx";

export default function ProductGrid({ products }) {
  if (!products.length) {
    return (
      <EmptyState
        title="No products found"
        message="Try changing the search term, category, or sorting option."
      />
    );
  }

  return (
    <section className="product-grid">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </section>
  );
}