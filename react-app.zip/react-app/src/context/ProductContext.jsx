import { createContext, useCallback, useEffect, useMemo, useState } from "react";
import {
  fetchCategories,
  fetchProducts,
  searchProducts,
} from "../services/productService.js";

const ProductContext = createContext(null);

export function ProductProvider({ children }) {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortOption, setSortOption] = useState("default");
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 8;

  const loadProducts = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const [productData, categoryData] = await Promise.all([
        fetchProducts({ limit: 100 }),
        fetchCategories(),
      ]);

      setProducts(productData.products || []);
      setCategories(categoryData || []);
    } catch (err) {
      setError(err.message || "Unable to load products.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter((product) =>
        product.title.toLowerCase().includes(query)
      );
    }

    if (selectedCategory !== "all") {
      result = result.filter(
        (product) => product.category === selectedCategory
      );
    }

    if (sortOption === "price-low-high") {
      result.sort((a, b) => a.price - b.price);
    } else if (sortOption === "price-high-low") {
      result.sort((a, b) => b.price - a.price);
    } else if (sortOption === "rating-high-low") {
      result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [products, searchQuery, selectedCategory, sortOption]);

  const totalPages = Math.max(
    1,
    Math.ceil(filteredProducts.length / productsPerPage)
  );

  const visibleProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * productsPerPage;
    return filteredProducts.slice(startIndex, startIndex + productsPerPage);
  }, [filteredProducts, currentPage]);

  const featuredProducts = useMemo(
    () =>
      [...products]
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 4),
    [products]
  );

  const value = {
    products,
    featuredProducts,
    categories,
    loading,
    error,
    searchQuery,
    selectedCategory,
    sortOption,
    currentPage,
    totalPages,
    visibleProducts,
    filteredProducts,
    setSearchQuery,
    setSelectedCategory,
    setSortOption,
    setCurrentPage,
    reloadProducts: loadProducts,
  };

  return (
    <ProductContext.Provider value={value}>
      {children}
    </ProductContext.Provider>
  );
}

export default ProductContext;