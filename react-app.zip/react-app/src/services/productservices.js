const BASE_URL = "https://dummyjson.com/products";

async function request(url) {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }

  return response.json();
}

export async function fetchProducts({ limit = 30, skip = 0 } = {}) {
  return request(`${BASE_URL}?limit=${limit}&skip=${skip}`);
}

export async function fetchProductById(id) {
  return request(`${BASE_URL}/${id}`);
}

export async function fetchCategories() {
  return request(`${BASE_URL}/categories`);
}

export async function searchProducts(query) {
  return request(`${BASE_URL}/search?q=${encodeURIComponent(query)}`);
}