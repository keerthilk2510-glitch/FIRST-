import { useProducts } from "../hooks/useProducts.js";
import ProductGrid from "../components/ProductGrid.jsx";
import CategoryFilter from "../components/CategoryFilter.jsx";
import SortSelect from "../components/SortSelect.jsx";
import Loader from "../components/Loader.jsx";
import ErrorState from "../components/ErrorState.jsx";

export default function Products() {
  const {
    visibleProducts,
    filteredProducts,
    loading,
    error,
    currentPage,
    totalPages,
    setCurrentPage,
    reloadProducts,
  } = useProducts();

  return (
    <div className="products-page">
      <section className="page-hero">
        <h1>Explore the Collection</h1>
        <p>
          Showing {filteredProducts.length} product
          {filteredProducts.length !== 1 ? "s" : ""}.
        </p>
      </section>

      <CategoryFilter />
      <SortSelect />

      {loading ? (
        <Loader label="Loading products..." />
      ) : error ? (
        <ErrorState message={error} onRetry={reloadProducts} />
      ) : (
        <>
          <ProductGrid products={visibleProducts} />

          {totalPages > 1 && (
            <div className="pagination">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(currentPage - 1)}
              >
                Previous
              </button>

              {Array.from({ length: totalPages }, (_, index) => index + 1).map(
                (page) => (
                  <button
                    key={page}
                    className={page === currentPage ? "active" : ""}
                    onClick={() => setCurrentPage(page)}
                  >
                    {page}
                  </button>
                )
              )}

              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(currentPage + 1)}
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}