import { Link } from "react-router-dom";
import { useCart } from "../hooks/useCart.js";
import QuantityControl from "../components/QuantityControl.jsx";
import EmptyState from "../components/EmptyState.jsx";

export default function Cart() {
  const {
    cartItems,
    cartCount,
    cartTotal,
    updateQuantity,
    removeFromCart,
    clearCart,
  } = useCart();

  if (!cartItems.length) {
    return (
      <EmptyState
        title="Your cart is empty"
        message="Browse the collection and add products you love."
        action={
          <Link to="/products" className="primary-button">
            Start Shopping
          </Link>
        }
      />
    );
  }

  return (
    <div className="cart-page">
      <h1>Shopping Cart</h1>

      <div className="cart-layout">
        <section className="cart-items">
          {cartItems.map((item) => (
            <article key={item.id} className="cart-item">
              <img src={item.thumbnail} alt={item.title} />

              <div className="cart-item-info">
                <Link to={`/products/${item.id}`}>{item.title}</Link>
                <span className="muted">{item.category}</span>
                <strong>${item.price.toFixed(2)}</strong>
              </div>

              <QuantityControl
                quantity={item.quantity}
                onIncrease={() => updateQuantity(item.id, item.quantity + 1)}
                onDecrease={() => updateQuantity(item.id, item.quantity - 1)}
              />

              <div className="cart-item-total">
                <strong>${(item.price * item.quantity).toFixed(2)}</strong>
                <button onClick={() => removeFromCart(item.id)}>Remove</button>
              </div>
            </article>
          ))}

          <button className="ghost-button" onClick={clearCart}>
            Clear Cart
          </button>
        </section>

        <aside className="cart-summary">
          <h2>Order Summary</h2>

          <div className="summary-row">
            <span>Total Items</span>
            <strong>{cartCount}</strong>
          </div>

          <div className="summary-row">
            <span>Subtotal</span>
            <strong>${cartTotal.toFixed(2)}</strong>
          </div>

          <div className="summary-row">
            <span>Shipping</span>
            <strong>Free</strong>
          </div>

          <div className="summary-row total">
            <span>Total</span>
            <strong>${cartTotal.toFixed(2)}</strong>
          </div>

          <button className="primary-button full-width">Proceed to Checkout</button>
        </aside>
      </div>
    </div>
  );
}