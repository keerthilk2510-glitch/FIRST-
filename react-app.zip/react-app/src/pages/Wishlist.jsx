import { Link } from "react-router-dom";
import { useCart } from "../hooks/useCart.js";
import ProductGrid from "../components/ProductGrid.jsx";
import EmptyState from "../components/EmptyState.jsx";

export default function Wishlist() {
  const { wishlist } = useCart();

  if (!wishlist.length) {
    return (
      <EmptyState
        title="No wishlist items yet"
        message="Save products you like and find them here later."
        action={
          <Link to="/products" className="primary-button">
            Browse Products
          </Link>
        }
      />
    );
  }

  return (
    <div className="wishlist-page">
      <h1>Your Wishlist</h1>
      <ProductGrid products={wishlist} />
    </div>
  );
}