import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { fetchProductById } from "../services/productService.js";
import { useCart } from "../hooks/useCart.js";
import QuantityControl from "../components/QuantityControl.jsx";
import Loader from "../components/Loader.jsx";
import ErrorState from "../components/ErrorState.jsx";

export default function ProductDetails() {
  const { id } = useParams();
  const { addToCart, toggleWishlist, wishlist } = useCart();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    let isActive = true;
    setLoading(true);
    setError(null);

    fetchProductById(id)
      .then((data) => {
        if (isActive) setProduct(data);
      })
      .catch((err) => {
        if (isActive) setError(err.message);
      })
      .finally(() => {
        if (isActive) setLoading(false);
      });

    return () => {
      isActive = false;
    };
  }, [id]);

  if (loading) return <Loader label="Loading product details..." />;

  if (error) {
    return <ErrorState message={error} onRetry={() => window.location.reload()} />;
  }

  if (!product) return null;

  const isWishlisted = wishlist.some((item) => item.id === product.id);
  const finalPrice = product.price;
  const originalPrice =
    product.discountPercentage > 0
      ? product.price / (1 - product.discountPercentage / 100)
      : null;

  return (
    <div className="product-details-page">
      <Link to="/products" className="back-link">
        ← Back to shop
      </Link>

      <div className="details-layout">
        <div className="gallery">
          <img
            src={product.images[activeImage]}
            alt={product.title}
            className="main-image"
          />

          <div className="thumbnail-row">
            {product.images.map((image, index) => (
              <button
                key={image}
                className={`thumbnail ${
                  index === activeImage ? "active" : ""
                }`}
                onClick={() => setActiveImage(index)}
              >
                <img src={image} alt={`${product.title} view ${index + 1}`} />
              </button>
            ))}
          </div>
        </div>

        <div className="details-info">
          <span className="product-category">{product.category}</span>
          <h1>{product.title}</h1>

          <div className="rating-row">
            <span>★ {product.rating.toFixed(1)}</span>
            <span>{product.stock} in stock</span>
          </div>

          <div className="price-row">
            <span className="current-price">${finalPrice.toFixed(2)}</span>
            {originalPrice && (
              <span className="old-price">${originalPrice.toFixed(2)}</span>
            )}
            {product.discountPercentage > 0 && (
              <span className="discount-badge">
                -{Math.round(product.discountPercentage)}%
              </span>
            )}
          </div>

          <p className="description">{product.description}</p>

          <div className="details-actions">
            <QuantityControl
              quantity={quantity}
              onIncrease={() => setQuantity((q) => q + 1)}
              onDecrease={() => setQuantity((q) => Math.max(1, q - 1))}
            />

            <button
              className="primary-button"
              onClick={() => addToCart(product, quantity)}
            >
              Add to Cart
            </button>

            <button
              className={`outline-button ${isWishlisted ? "active" : ""}`}
              onClick={() => toggleWishlist(product)}
            >
              {isWishlisted ? "♥ Wishlisted" : "♡ Add to Wishlist"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}