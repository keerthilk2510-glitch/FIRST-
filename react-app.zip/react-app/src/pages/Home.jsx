import { Link } from "react-router-dom";
import { useProducts } from "../hooks/useProducts.js";
import ProductGrid from "../components/ProductGrid.jsx";
import Loader from "../components/Loader.jsx";
import ErrorState from "../components/ErrorState.jsx";

export default function Home() {
  const { featuredProducts, loading, error, reloadProducts } = useProducts();

  return (
    <div className="home-page">
      <section className="hero">
        <div className="hero-content">
          <span className="eyebrow">New Season Collection</span>
          <h1>
            Shop smarter with a beautifully fast <span>NovaCart</span> experience.
          </h1>
          <p>
            Discover curated products, manage your cart instantly, and enjoy a
            fully responsive shopping interface.
          </p>

          <div className="hero-actions">
            <Link to="/products" className="primary-button">
              Explore Products
            </Link>
            <Link to="/cart" className="outline-button">
              View Cart
            </Link>
          </div>
        </div>

        <div className="hero-visual">
          <div className="floating-card card-one">
            <strong>Fast Cart Updates</strong>
            <p>Context-powered global state</p>
          </div>
          <div className="floating-card card-two">
            <strong>Smart Filtering</strong>
            <p>Search, category and price sorting</p>
          </div>
          <div className="floating-card card-three">
            <strong>Dark Mode</strong>
            <p>Modern user preference support</p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div>
            <h2>Featured Products</h2>
            <p>Top-rated selections from the catalogue.</p>
          </div>
          <Link to="/products" className="outline-button">
            View all
          </Link>
        </div>

        {loading ? (
          <Loader label="Loading featured products..." />
        ) : error ? (
          <ErrorState message={error} onRetry={reloadProducts} />
        ) : (
          <ProductGrid products={featuredProducts} />
        )}
      </section>
    </div>
  );
}