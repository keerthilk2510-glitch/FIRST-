export type CottonDiseaseClass =
  | 'Bacterial Blight'
  | 'Curl Virus'
  | 'Healthy Leaf'
  | 'Herbicide Growth Damage'
  | 'Leaf Hopper Jassids'
  | 'Leaf Redding'
  | 'Leaf Variegation';

export type SeverityLevel = 'Healthy' | 'Low' | 'Moderate' | 'Critical';

export interface ClassProbability {
  className: CottonDiseaseClass;
  probability: number; // 0 to 1
  isPrimary?: boolean;
}

export interface AdvisoryDetails {
  scientificName: string;
  pathogenType: string; // 'Bacterium' | 'Begomovirus' | 'Abiotic / Chemical' | 'Insect Pest' | 'Nutrient / Abiotic' | 'Genetic / Mosaic' | 'None (Healthy)'
  overview: string;
  symptoms: string[];
  severity: SeverityLevel;
  affectedAreaPercentage: number;
  economicThreshold?: string;
  remediation: {
    immediateAction: string[];
    organicTreatment: string[];
    chemicalTreatment: string[];
    preventionTips: string[];
  };
  suitableWeatherConditions?: string;
}

export interface DetectionResult {
  id: string;
  timestamp: string;
  condition: CottonDiseaseClass;
  confidence: number; // 0 to 1
  severity: SeverityLevel;
  symptomsIdentified: string[];
  affectedAreaPercentage: number;
  pathologyNotes: string;
  classProbabilities: ClassProbability[];
  advisory: AdvisoryDetails;
  inferenceLatencyMs: number;
  modelEngine: string; // 'MobileNetV2 / EfficientNetB0 + Gemini 3.8 Vision'
  imageUrl?: string;
  fieldLocation?: string;
  plotNumber?: string;
}

export interface AdvisoryRecord {
  id: string;
  timestamp: string;
  condition: CottonDiseaseClass;
  confidence: number;
  severity: SeverityLevel;
  imageUrl?: string;
  thumbnailUrl?: string;
  plotNumber: string;
  fieldLocation: string;
  farmerNotes: string;
  status: 'Active Alert' | 'Treatment Scheduled' | 'Remediated' | 'Archived';
  advisory: AdvisoryDetails;
  actionTakenNotes?: string;
  updatedAt?: string;
}

export interface DatasetMetrics {
  name: string;
  totalSamples: number;
  classesCount: number;
  trainSplit: number;
  valSplit: number;
  testSplit: number;
  models: {
    modelName: string;
    accuracy: number;
    precision: number;
    recall: number;
    f1Score: number;
    inferenceLatencyMs: number;
    modelSizeMb: number;
  }[];
  confusionMatrix: {
    classes: CottonDiseaseClass[];
    matrix: number[][]; // 7x7 counts or percentages
  };
}
