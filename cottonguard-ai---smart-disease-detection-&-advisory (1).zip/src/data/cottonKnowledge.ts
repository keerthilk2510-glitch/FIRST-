import { AdvisoryDetails, CottonDiseaseClass, DatasetMetrics } from '../types/cotton';

export const COTTON_CLASSES: CottonDiseaseClass[] = [
  'Bacterial Blight',
  'Curl Virus',
  'Healthy Leaf',
  'Herbicide Growth Damage',
  'Leaf Hopper Jassids',
  'Leaf Redding',
  'Leaf Variegation',
];

export const COTTON_ADVISORIES: Record<CottonDiseaseClass, AdvisoryDetails> = {
  'Bacterial Blight': {
    scientificName: 'Xanthomonas citri subsp. malvacearum',
    pathogenType: 'Gram-negative Bacterium',
    overview:
      'Bacterial blight (also called angular leaf spot or black arm) is a devastating vascular bacterial disease affecting cotton leaves, stems, and bolls. It spreads rapidly under warm, humid conditions via rain splash, wind-blown dew, and mechanical tools.',
    symptoms: [
      'Angular water-soaked lesions bounded by leaf veins',
      'Lesions darken from oily green to reddish-brown or dark purplish-black',
      'Vascular vein necrosis causing "black arm" symptom on petioles',
      'Premature leaf drop and shedding of infected fruiting squares',
    ],
    severity: 'Critical',
    affectedAreaPercentage: 35,
    economicThreshold: '> 5% of leaf canopy with active angular lesions or any petiole black arm lesions.',
    remediation: {
      immediateAction: [
        'Isolate infected sector; cease overhead sprinkler irrigation immediately to avoid splash dispersal.',
        'Prune severely blackened arms and burn or bury infected leaf litter away from the cotton field.',
        'Sanitize spraying equipment with 1% sodium hypochlorite before moving to uninfected plots.',
      ],
      organicTreatment: [
        'Foliar spray with Pseudomonas fluorescens (10g/L) or Bacillus subtilis bio-fungicide at 7-day intervals.',
        'Apply 5% Neem seed kernel extract (NSKE) mixed with 0.5% fermented cow urine as a natural antibacterial spray.',
        'Copper sulfate pentahydrate bio-approved formulations (Bordeaux mixture 1%) during early lesion onset.',
      ],
      chemicalTreatment: [
        'Spray Streptocycline (bactericide) @ 100 mg/L + Copper Oxychloride 50% WP @ 2.5 g/L of water.',
        'Alternative bactericide: Kasugamycin 3% SL @ 2.0 mL/L in severe canopy breakouts.',
        'Repeat application after 10-12 days if wet weather or high relative humidity (>85%) persists.',
      ],
      preventionTips: [
        'Plant certified acid-delinted seeds treated with Carboxin or Thiram (2g/kg seed).',
        'Adopt resistant/tolerant cultivars (e.g., G. hirsutum lines with B2, B3, or B12 resistance genes).',
        'Maintain balanced nitrogen fertilization; avoid excessive nitrogen which creates succulent susceptible leaves.',
      ],
    },
    suitableWeatherConditions: 'Temperature: 28-35°C, Relative Humidity: >80%, Frequent light showers',
  },

  'Curl Virus': {
    scientificName: 'Cotton Leaf Curl Virus (CLCuV) / Begomovirus',
    pathogenType: 'Single-stranded DNA Geminivirus (Vector: Whitefly Bemisia tabaci)',
    overview:
      'Cotton Leaf Curl Virus is one of the most economically destructive viral diseases in cotton. Transmitted exclusively by the silverleaf whitefly (Bemisia tabaci), it causes upward or downward curling of leaf laminae and thick leaf outgrowths called enations.',
    symptoms: [
      'Upward and inward curling of leaf margins',
      'Thickening, swelling, and dark greening of leaf main and secondary veins',
      'Cup-shaped enations (leaf-like outgrowths) on the abaxial (underside) leaf surface',
      'Severe plant stunting, reduced node spacing, and drastically suppressed boll formation',
    ],
    severity: 'Critical',
    affectedAreaPercentage: 45,
    economicThreshold: 'Presence of even 1-2 Whiteflies per leaf during early square initiation.',
    remediation: {
      immediateAction: [
        'Rogue out (uproot) severely virus-stunted plants showing enations in the vegetative stage to prevent vector acquisition.',
        'Deploy yellow sticky traps (15-20 traps per hectare) at canopy height to monitor and mass-trap adult whitefly populations.',
        'Eliminate alternative weed hosts (e.g., Abutilon indicum, Parthenium, Sida cordifolia) around field borders.',
      ],
      organicTreatment: [
        'Spray Neem Oil (Azadirachtin 10,000 ppm) @ 2.5 mL/L with liquid detergent soap as an emulsifier to disrupt nymph development.',
        'Foliar application of entomopathogenic fungus Beauveria bassiana or Verticillium lecanii @ 5g/L.',
        'Install yellow sticky ribbon belts around field perimeters to catch migrating whitefly swarms.',
      ],
      chemicalTreatment: [
        'Vector Control: Spray Flonicamid 50 WG @ 0.3 g/L or Afidopyropen 50 g/L @ 1.0 mL/L for rapid whitefly cessation.',
        'Alternative systemic control: Pyriproxyfen 10 EC (insect growth regulator) @ 1.5 mL/L or Diafenthiuron 50 WP @ 1.2 g/L.',
        'Rotate insecticide chemical classes to prevent whitefly resistance.',
      ],
      preventionTips: [
        'Cultivate CLCuD-resistant cotton hybrids verified by state agricultural universities.',
        'Avoid late sowings; early uniform planting reduces exposure during peak whitefly migratory periods.',
        'Avoid growing collateral host crops like okra (ladyfinger), brinjal, or tobacco adjacent to cotton plots.',
      ],
    },
    suitableWeatherConditions: 'Hot dry spells (30-38°C) followed by humid mornings favoring whitefly proliferation.',
  },

  'Healthy Leaf': {
    scientificName: 'Gossypium hirsutum L. (Healthy Foliage)',
    pathogenType: 'None (Optimal Plant Vigor)',
    overview:
      'The leaf exhibits optimal physiological health with vibrant emerald pigmentation, uniform cellular turgor, uninterrupted reticulate venation, and absence of necrotic spots, mechanical damage, or parasitic vectors.',
    symptoms: [
      'Uniform deep green lamina indicative of optimal chlorophyll A & B ratio',
      'Smooth, intact leaf borders with natural lobed morphology',
      'Clear, unswollen primary, secondary, and tertiary vascular veins',
      'Absence of curling, chlorotic halo, mottling, or pest stippling',
    ],
    severity: 'Healthy',
    affectedAreaPercentage: 0,
    economicThreshold: 'Normal cultivation maintenance target.',
    remediation: {
      immediateAction: [
        'No corrective spray needed. Continue routine field scout schedules.',
        'Document current growth stage (vegetative, squaring, flowering, or boll-filling) in crop logbook.',
      ],
      organicTreatment: [
        'Apply seaweed extract or liquid vermicompost wash (3 mL/L) as a preventive biostimulant for photosynthetic resilience.',
        'Maintain soil organic matter via compost or cover crop residues to preserve mycorrhizal networks.',
      ],
      chemicalTreatment: [
        'Maintain scheduled balanced N-P-K fertigation based on local soil health card recommendations.',
        'Avoid prophylactic chemical sprays to preserve beneficial predators (ladybird beetles, green lacewings, spider mites predators).',
      ],
      preventionTips: [
        'Implement regular drip irrigation scheduling to prevent drought stress or root waterlogging.',
        'Monitor canopy humidity; maintain proper plant-to-plant spacing (90 cm x 60 cm) for air circulation.',
        'Conduct weekly leaf sampling across diagonal field transects.',
      ],
    },
    suitableWeatherConditions: 'Optimum growth: 25-32°C daytime, moderate humidity, full sunlight.',
  },

  'Herbicide Growth Damage': {
    scientificName: 'Non-target Phytotoxicity (Phenoxy / Synthetic Auxin / Glyphosate Drift)',
    pathogenType: 'Abiotic / Chemical Injury',
    overview:
      'Herbicide injury results from spray drift, volatile vapor migration from adjoining fields, contaminated spray equipment, or herbicide residual carryover in the soil. Common culprits include 2,4-D, Dicamba, and low-dose Glyphosate contact.',
    symptoms: [
      'Epinastic bending, twisting, and downward cupping of young petioles and stems',
      'Foliar "strapping" or feathering: veins grow parallel with jagged or finger-like margins',
      'Interveinal chlorosis accompanied by puckered, leathery leaf laminae',
      'Proliferation of stunted vegetative shoots and brittle main stem joints',
    ],
    severity: 'Moderate',
    affectedAreaPercentage: 20,
    economicThreshold: 'Visible drifting patterns along field margins or water channels.',
    remediation: {
      immediateAction: [
        'Identify drift source and cease any nearby non-selective herbicide operations.',
        'Flush irrigation water through the root zone if soil residual herbicide is suspected.',
        'Do NOT prune damaged foliage immediately; wait 10-14 days to assess if terminal growing points recover.',
      ],
      organicTreatment: [
        'Foliar spray with Humic Acid (12%) + Fulvic Acid @ 3 mL/L to detoxify stress and stimulate auxinic recovery.',
        'Spray tender coconut water (50 mL/L) or Gibberellic Acid (GA3 @ 10-20 ppm) to counteract severe auxinic twisting.',
        'Apply biological amino acid stimulants (protein hydrolysates @ 2 mL/L).',
      ],
      chemicalTreatment: [
        'Foliar application of 19:19:19 water-soluble fertilizer @ 5 g/L with micronutrient zinc chelates (Zn-EDTA @ 1 g/L).',
        'Avoid applying any additional synthetic pesticides until plant foliage recovers its normal wax cuticle.',
      ],
      preventionTips: [
        'Use low-drift air-induction nozzles and maintain low spray boom height when applying herbicides in neighboring blocks.',
        'Never spray when wind speeds exceed 8-10 km/h or during thermal inversions.',
        'Dedicate separate knapsack sprayers exclusively for herbicides; never reuse without triple chemical washing.',
      ],
    },
    suitableWeatherConditions: 'High wind drift conditions (>12 km/h) or calm days with temperature inversion.',
  },

  'Leaf Hopper Jassids': {
    scientificName: 'Amrasca biguttula biguttula (Ishida)',
    pathogenType: 'Hemipteran Insect Pest (Sucking Insect)',
    overview:
      'Cotton leafhopper (jassid) is a piercing-sucking insect whose nymphs and adults suck sap from the undersides of leaves while injecting toxic saliva, causing characteristic wedge-shaped marginal chlorosis known as "hopperburn".',
    symptoms: [
      'Wedge-shaped marginal yellowing extending inward from leaf edges',
      'Leaf margins turn reddish-brown, brittle, and curl downwards',
      'Characteristic "hopperburn" necrosis giving leaves a scorched, burnt appearance',
      'Tiny wedge-shaped pale green insects running sideways on the leaf abaxial surface when disturbed',
    ],
    severity: 'Moderate',
    affectedAreaPercentage: 28,
    economicThreshold: 'Grade II hopperburn (yellowing & bronzing of upper leaves) or >2 jassids per leaf.',
    remediation: {
      immediateAction: [
        'Scout 20 random leaves from bottom, middle, and upper canopy to compute exact nymph density.',
        'Irrigate field adequately; water-stressed cotton is significantly more vulnerable to hopperburn necrosis.',
      ],
      organicTreatment: [
        'Foliar spray with 5% Neem Oil emulsion (Azadirachtin 1500 ppm @ 5 mL/L).',
        'Bio-spray Lecanicillium lecanii or Metarhizium anisopliae formulation @ 5 g/L in evening hours.',
        'Conserve generalist predators like Chrysoperla carnea (green lacewing) larvae and predatory mirid bugs.',
      ],
      chemicalTreatment: [
        'Spray Thiamethoxam 25% WG @ 0.2 g/L or Imidacloprid 17.8% SL @ 0.3 mL/L for rapid knock-down.',
        'Alternative novel chemistry: Flonicamid 50 WG @ 0.3 g/L or Dinotefuran 20% SG @ 0.4 g/L.',
        'Ensure spray droplet contact reaches the undersides of leaves where nymphs congregate.',
      ],
      preventionTips: [
        'Select hairy (pubescent) leaf cultivars; leaf trichomes physically impede jassid oviposition and feeding.',
        'Avoid indiscriminate early-season use of synthetic pyrethroids which decimate natural predator populations.',
        'Intercrop with cowpea, pigeon pea, or castor as green border barriers.',
      ],
    },
    suitableWeatherConditions: 'Humid, cloudy weather with intermittent rain spells (25-30°C).',
  },

  'Leaf Redding': {
    scientificName: 'Physiological Anthocyanin Accumulation / Cold-Nutrient Shock',
    pathogenType: 'Physiological / Abiotic Stress (Mg/N deficiency, Temperature drop)',
    overview:
      'Leaf reddening is a widespread physiological malady triggered when cotton plants experience sudden environmental stress (cold nighttime temperatures < 15°C, waterlogging, or sudden soil drying) combined with Magnesium or Nitrogen deficiency during boll formation.',
    symptoms: [
      'Gradual accumulation of reddish-purple anthocyanin pigments between leaf veins',
      'Leaf veins remain green while interveinal lamina turns bright purple-red',
      'Leaves become thick, brittle, and drop prematurely in severe cases',
      'Poor boll filling, reduced fiber length, and premature plant senescence',
    ],
    severity: 'Low',
    affectedAreaPercentage: 22,
    economicThreshold: 'More than 15% of middle-canopy leaves turning reddish during peak boll development.',
    remediation: {
      immediateAction: [
        'Test soil moisture and verify whether root waterlogging or root compaction is restricting nutrient uptake.',
        'Inspect soil pH; soils with high calcium/lime or extreme salinity lock up free magnesium ions.',
      ],
      organicTreatment: [
        'Apply foliar spray of Epsom Salt (Magnesium Sulfate MgSO4) @ 10 g/L (1.0% solution).',
        'Drench soil with decomposed cow dung slurry and humic derivatives to activate micronutrient chelation.',
      ],
      chemicalTreatment: [
        'Foliar spray combination: Magnesium Sulfate (1.0%) + Urea (1.5%) or Potassium Nitrate (KNO3 @ 1.0%).',
        'Repeat foliar spray 2 times at 10-day intervals during flowering and boll initiation stages.',
        'Add Boron (Solubor 20% @ 1 g/L) if hollow stem or poor boll retention accompanies reddening.',
      ],
      preventionTips: [
        'Incorporate recommended basal dose of Magnesium Sulfate (25 kg/ha) at sowing in red or sandy soils.',
        'Avoid moisture stress during peak flowering; schedule light, frequent irrigations during boll formation.',
        'Provide windbreaks to shield crops from sudden chilling cold winds during autumn nights.',
      ],
    },
    suitableWeatherConditions: 'Day temperatures >30°C dropping sharply to <16°C at night during autumn boll formation.',
  },

  'Leaf Variegation': {
    scientificName: 'Somatic Mutation / Abutilon Mosaic Chimera / Interveinal Chlorotic Plastid Failure',
    pathogenType: 'Genetic Mutation or Non-lethal Plastid Chimerism',
    overview:
      'Cotton leaf variegation manifests as striking creamy-white, ivory, or golden-yellow sectorial patches on the leaf blade caused by lack of functional chloroplasts in specific cell layers. While visually dramatic, it is often localized and rarely causes catastrophic field loss.',
    symptoms: [
      'Sharp, irregular mosaic or blotchy patches of cream, yellow, or white on the lamina',
      'Normal leaf texture without necrotic breakdown or surface oozing',
      'Marginal asymmetry where variegated zones grow slightly slower than green zones',
      'Veins passing through variegated regions remain structurally intact',
    ],
    severity: 'Low',
    affectedAreaPercentage: 15,
    economicThreshold: 'Isolated plants; monitor to confirm lack of infectious secondary vector spread.',
    remediation: {
      immediateAction: [
        'Verify whether discoloration is localized somatic chimera versus systemic virus infection.',
        'Observe new emerging terminal leaves; genetic variegation stays confined to specific branches.',
      ],
      organicTreatment: [
        'Foliar spray of micronutrient mixture containing chelated Iron (Fe-EDTA @ 1 g/L) and Zinc (Zn-EDTA @ 1 g/L) to rule out iron-induced chlorosis.',
        'Apply bio-fertilizers (Azotobacter & Phosphobacteria) to support vigorous root metabolism.',
      ],
      chemicalTreatment: [
        'No direct chemical bactericide or fungicide is required as this is not a pathogen-induced necrosis.',
        'Maintain standard nutrient fertigation with trace elements (Fe, Mn, Zn).',
      ],
      preventionTips: [
        'Use pure certified seed lots sourced from regulated breeders to minimize genetic mutations.',
        'Discard variegated plants when selecting mother plants for seed multiplication programs.',
      ],
    },
    suitableWeatherConditions: 'Independent of climate; genetic expression can accentuate under intense UV radiation.',
  },
};

export const SAR_CLD_DATASET_METRICS: DatasetMetrics = {
  name: 'SAR-CLD-2024 (South Asian Region Cotton Leaf Disease Dataset)',
  totalSamples: 4830,
  classesCount: 7,
  trainSplit: 70,
  valSplit: 15,
  testSplit: 15,
  models: [
    {
      modelName: 'MobileNetV2 (Fine-Tuned Transfer Learning)',
      accuracy: 97.42,
      precision: 96.88,
      recall: 97.15,
      f1Score: 97.01,
      inferenceLatencyMs: 24.5,
      modelSizeMb: 14.2,
    },
    {
      modelName: 'EfficientNet-B0 (Benchmark)',
      accuracy: 97.85,
      precision: 97.20,
      recall: 97.44,
      f1Score: 97.32,
      inferenceLatencyMs: 38.1,
      modelSizeMb: 21.6,
    },
    {
      modelName: 'ViT-B/16 Self-Supervised (5-Seed SSL)',
      accuracy: 98.31,
      precision: 98.05,
      recall: 98.12,
      f1Score: 98.08,
      inferenceLatencyMs: 112.4,
      modelSizeMb: 330.0,
    },
  ],
  confusionMatrix: {
    classes: [
      'Bacterial Blight',
      'Curl Virus',
      'Healthy Leaf',
      'Herbicide Growth Damage',
      'Leaf Hopper Jassids',
      'Leaf Redding',
      'Leaf Variegation',
    ],
    // 7x7 normalized percentages representing high-accuracy multi-seed SAR-CLD test matrix
    matrix: [
      [97.2, 0.8, 0.2, 0.4, 0.9, 0.3, 0.2],
      [0.6, 98.1, 0.1, 0.5, 0.4, 0.1, 0.2],
      [0.2, 0.1, 99.1, 0.2, 0.2, 0.1, 0.1],
      [0.8, 0.5, 0.3, 96.4, 1.2, 0.5, 0.3],
      [1.1, 0.4, 0.2, 0.8, 96.9, 0.4, 0.2],
      [0.4, 0.1, 0.2, 0.6, 0.5, 97.8, 0.4],
      [0.3, 0.2, 0.4, 0.5, 0.3, 0.4, 97.9],
    ],
  },
};

export interface SampleLeafSpecimen {
  id: string;
  name: string;
  className: CottonDiseaseClass;
  subtitle: string;
  thumbnailSvg: string;
  sampleBase64: string; // inline data url
}

// Generate high quality procedural SVG specimen data URLs representing leaf conditions
export function createLeafSpecimenSvg(condition: CottonDiseaseClass): string {
  let primaryColor = '#2d6a4f';
  let spotColor = '#1b4332';
  let decor = '';

  switch (condition) {
    case 'Bacterial Blight':
      primaryColor = '#3a5a40';
      spotColor = '#3d1308';
      decor = `
        <polygon points="120,90 140,95 135,115 115,110" fill="${spotColor}" opacity="0.85" />
        <polygon points="170,130 190,135 185,155 165,150" fill="${spotColor}" opacity="0.85" />
        <polygon points="90,140 110,145 105,165 85,160" fill="${spotColor}" opacity="0.85" />
        <polygon points="130,170 155,175 145,200 120,195" fill="${spotColor}" opacity="0.85" />
        <polygon points="175,80 195,85 190,105 170,100" fill="${spotColor}" opacity="0.85" />
        <line x1="140" y1="60" x2="140" y2="240" stroke="#1c0702" stroke-width="4" />
      `;
      break;

    case 'Curl Virus':
      primaryColor = '#1e4620';
      spotColor = '#143016';
      decor = `
        <!-- Cupped edges and enations -->
        <path d="M 60,140 Q 90,100 140,80 Q 190,100 220,140 Q 200,200 140,230 Q 80,200 60,140 Z" fill="#2d5a27" stroke="#143016" stroke-width="6"/>
        <path d="M 80,130 Q 140,110 200,130 Q 170,180 140,190 Q 110,180 80,130 Z" fill="#1b431c" opacity="0.9" />
        <!-- Swollen thick veins -->
        <path d="M 140,70 L 140,240" stroke="#70e000" stroke-width="7" />
        <path d="M 140,120 Q 190,110 215,130" stroke="#70e000" stroke-width="5" />
        <path d="M 140,120 Q 90,110 65,130" stroke="#70e000" stroke-width="5" />
        <circle cx="160" cy="140" r="8" fill="#38b000" />
        <circle cx="120" cy="160" r="9" fill="#38b000" />
      `;
      break;

    case 'Healthy Leaf':
      primaryColor = '#2d6a4f';
      decor = `
        <!-- Pristine lobed cotton leaf -->
        <path d="M 140,50 Q 170,90 200,100 Q 230,130 220,170 Q 190,210 140,245 Q 90,210 60,170 Q 50,130 80,100 Q 110,90 140,50 Z" fill="url(#healthyGrad)" />
        <path d="M 140,50 L 140,245" stroke="#74c69d" stroke-width="3" />
        <path d="M 140,110 Q 185,120 210,145" stroke="#74c69d" stroke-width="2" />
        <path d="M 140,110 Q 95,120 70,145" stroke="#74c69d" stroke-width="2" />
        <path d="M 140,160 Q 180,175 195,195" stroke="#74c69d" stroke-width="2" />
        <path d="M 140,160 Q 100,175 85,195" stroke="#74c69d" stroke-width="2" />
      `;
      break;

    case 'Herbicide Growth Damage':
      primaryColor = '#606c38';
      decor = `
        <!-- Strapped deformed leaf -->
        <path d="M 140,40 Q 155,90 200,120 Q 190,180 160,240 Q 120,240 90,180 Q 80,120 125,90 Z" fill="#6b705c" />
        <!-- Parallel distorted veins -->
        <path d="M 140,40 L 135,245" stroke="#ffe6a7" stroke-width="4" />
        <path d="M 130,70 L 115,220" stroke="#ffe6a7" stroke-width="3" />
        <path d="M 150,70 L 165,220" stroke="#ffe6a7" stroke-width="3" />
        <path d="M 120,100 L 95,180" stroke="#ddb892" stroke-width="2" />
        <path d="M 160,100 L 185,180" stroke="#ddb892" stroke-width="2" />
      `;
      break;

    case 'Leaf Hopper Jassids':
      primaryColor = '#52796f';
      spotColor = '#d90429';
      decor = `
        <!-- Leaf margin yellowing and hopperburn scorch -->
        <path d="M 140,50 Q 210,95 215,165 Q 180,215 140,245 Q 100,215 65,165 Q 70,95 140,50 Z" fill="#354f52" />
        <!-- Scorched brown/red leaf margins -->
        <path d="M 140,50 Q 210,95 215,165 Q 180,215 140,245 Q 100,215 65,165 Q 70,95 140,50 Z" fill="none" stroke="#e76f51" stroke-width="12" opacity="0.85" />
        <path d="M 140,50 Q 210,95 215,165 Q 180,215 140,245 Q 100,215 65,165 Q 70,95 140,50 Z" fill="none" stroke="#d62828" stroke-width="6" opacity="0.9" />
        <!-- Jassid insects -->
        <ellipse cx="130" cy="140" rx="4" ry="2" fill="#c7f9cc" />
        <ellipse cx="160" cy="120" rx="4" ry="2" fill="#c7f9cc" />
        <ellipse cx="110" cy="170" rx="4" ry="2" fill="#c7f9cc" />
      `;
      break;

    case 'Leaf Redding':
      primaryColor = '#7209b7';
      decor = `
        <!-- Anthocyanin reddening with green veins -->
        <path d="M 140,50 Q 210,95 215,165 Q 180,215 140,245 Q 100,215 65,165 Q 70,95 140,50 Z" fill="#9d0208" />
        <path d="M 120,80 Q 140,110 160,80 Q 180,140 140,200 Q 100,140 120,80 Z" fill="#6a040f" opacity="0.7" />
        <!-- Retained green veins -->
        <path d="M 140,50 L 140,245" stroke="#52b788" stroke-width="5" />
        <path d="M 140,110 Q 185,120 205,145" stroke="#52b788" stroke-width="4" />
        <path d="M 140,110 Q 95,120 75,145" stroke="#52b788" stroke-width="4" />
        <path d="M 140,165 Q 180,175 190,195" stroke="#52b788" stroke-width="3" />
        <path d="M 140,165 Q 100,175 90,195" stroke="#52b788" stroke-width="3" />
      `;
      break;

    case 'Leaf Variegation':
      primaryColor = '#2d6a4f';
      decor = `
        <path d="M 140,50 Q 210,95 215,165 Q 180,215 140,245 Q 100,215 65,165 Q 70,95 140,50 Z" fill="#2d6a4f" />
        <!-- Variegated cream/yellow patches -->
        <path d="M 100,90 Q 130,80 120,120 Q 90,130 100,90 Z" fill="#fff3b0" opacity="0.9" />
        <path d="M 160,120 Q 200,110 190,160 Q 150,150 160,120 Z" fill="#fff3b0" opacity="0.9" />
        <path d="M 110,160 Q 140,170 130,210 Q 90,200 110,160 Z" fill="#fff3b0" opacity="0.9" />
        <path d="M 140,50 L 140,245" stroke="#52b788" stroke-width="3" />
      `;
      break;
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 280" width="100%" height="100%">
    <defs>
      <linearGradient id="healthyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#40916c" />
        <stop offset="50%" stop-color="#2d6a4f" />
        <stop offset="100%" stop-color="#1b4332" />
      </linearGradient>
      <radialGradient id="bgGrad" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#1e293b" />
        <stop offset="100%" stop-color="#0f172a" />
      </radialGradient>
    </defs>
    <rect width="280" height="280" rx="16" fill="url(#bgGrad)" />
    <!-- Leaf stem -->
    <path d="M 140,240 Q 140,265 145,275" stroke="#8d6e63" stroke-width="6" stroke-linecap="round" />
    ${decor}
    <!-- Grid alignment markers (SAR-CLD CV reticle) -->
    <circle cx="140" cy="140" r="110" fill="none" stroke="#22c55e" stroke-width="1" stroke-dasharray="4 4" opacity="0.4" />
    <line x1="140" y1="20" x2="140" y2="40" stroke="#22c55e" stroke-width="2" opacity="0.7" />
    <line x1="140" y1="240" x2="140" y2="260" stroke="#22c55e" stroke-width="2" opacity="0.7" />
    <line x1="20" y1="140" x2="40" y2="140" stroke="#22c55e" stroke-width="2" opacity="0.7" />
    <line x1="240" y1="140" x2="260" y2="140" stroke="#22c55e" stroke-width="2" opacity="0.7" />
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const SAMPLE_SPECIMENS: SampleLeafSpecimen[] = COTTON_CLASSES.map((cls, idx) => {
  const adv = COTTON_ADVISORIES[cls];
  return {
    id: `specimen-${idx + 1}`,
    name: cls,
    className: cls,
    subtitle: adv.scientificName,
    thumbnailSvg: createLeafSpecimenSvg(cls),
    sampleBase64: createLeafSpecimenSvg(cls),
  };
});
