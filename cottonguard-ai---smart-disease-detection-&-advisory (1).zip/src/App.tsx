import React, { useState, useEffect, useCallback } from 'react';
import { Navbar, ActiveTab } from './components/Navbar';
import { LiveScanner } from './components/LiveScanner';
import { AdvisoryPanel } from './components/AdvisoryPanel';
import { AdvisoryDatabaseView } from './components/AdvisoryDatabaseView';
import { DatasetAnalytics } from './components/DatasetAnalytics';
import { CodeExporter } from './components/CodeExporter';
import { AdvisoryRecord, DetectionResult } from './types/cotton';
import { COTTON_ADVISORIES, COTTON_CLASSES } from './data/cottonKnowledge';
import { Leaf, ShieldCheck, Database, BarChart3, Info } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('scanner');
  const [currentDetection, setCurrentDetection] = useState<DetectionResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [databaseRecords, setDatabaseRecords] = useState<AdvisoryRecord[]>([]);
  const [isSavedToDb, setIsSavedToDb] = useState<boolean>(false);

  // Fetch Advisory Records from Server API
  const fetchRecords = useCallback(async () => {
    try {
      const res = await fetch('/api/advisories');
      if (res.ok) {
        const data = await res.json();
        setDatabaseRecords(data.records || []);
      }
    } catch (err) {
      console.warn('Could not fetch advisory database:', err);
    }
  }, []);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  // Handle Detection Complete from Live Scanner
  const handleDetectionComplete = (result: DetectionResult) => {
    setCurrentDetection(result);
    setIsSavedToDb(false);
    // Automatically switch to Advisory Panel so user immediately sees diagnosis & remedies
    setActiveTab('advisory');
  };

  // Save Current Detection to Advisory Database
  const handleSaveToDatabase = async (detection: DetectionResult): Promise<boolean> => {
    try {
      const res = await fetch('/api/advisories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          condition: detection.condition,
          confidence: detection.confidence,
          severity: detection.severity,
          imageUrl: detection.imageUrl,
          plotNumber: detection.plotNumber,
          fieldLocation: detection.fieldLocation,
          farmerNotes: `Live camera scan: ${detection.symptomsIdentified.slice(0, 2).join(', ')}`,
          advisory: detection.advisory,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setIsSavedToDb(true);
        // Refresh local database list
        setDatabaseRecords((prev) => [data.record, ...prev]);
        return true;
      }
    } catch (err) {
      console.error('Failed to save advisory to database:', err);
    }
    return false;
  };

  // Update Record in Database
  const handleUpdateRecord = async (id: string, updates: Partial<AdvisoryRecord>) => {
    try {
      const res = await fetch(`/api/advisories/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });

      if (res.ok) {
        const data = await res.json();
        setDatabaseRecords((prev) =>
          prev.map((r) => (r.id === id ? data.record : r))
        );
      }
    } catch (err) {
      console.error('Failed to update record:', err);
    }
  };

  // Delete Record from Database
  const handleDeleteRecord = async (id: string) => {
    if (!confirm('Are you sure you want to delete this advisory record?')) return;
    try {
      const res = await fetch(`/api/advisories/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setDatabaseRecords((prev) => prev.filter((r) => r.id !== id));
      }
    } catch (err) {
      console.error('Failed to delete record:', err);
    }
  };

  // Counts for Navbar
  const criticalCount = databaseRecords.filter((r) => r.severity === 'Critical').length;

  return (
    <div className="min-h-screen flex flex-col bg-[#f5f8f5] text-slate-800 antialiased selection:bg-emerald-500 selection:text-white">
      {/* Navbar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        hasActiveDetection={currentDetection !== null}
        databaseCount={databaseRecords.length}
        criticalAlertsCount={criticalCount}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'scanner' && (
          <LiveScanner
            onDetectionComplete={handleDetectionComplete}
            isAnalyzing={isAnalyzing}
            setIsAnalyzing={setIsAnalyzing}
          />
        )}

        {activeTab === 'advisory' && (
          <AdvisoryPanel
            detection={currentDetection}
            onSaveToDatabase={handleSaveToDatabase}
            isSavedToDb={isSavedToDb}
            onNavigateToScanner={() => setActiveTab('scanner')}
            onNavigateToDatabase={() => setActiveTab('database')}
          />
        )}

        {activeTab === 'database' && (
          <AdvisoryDatabaseView
            records={databaseRecords}
            onUpdateRecord={handleUpdateRecord}
            onDeleteRecord={handleDeleteRecord}
            onRefreshRecords={fetchRecords}
            onNavigateToScanner={() => setActiveTab('scanner')}
          />
        )}

        {activeTab === 'analytics' && <DatasetAnalytics />}

        {activeTab === 'code' && <CodeExporter />}
      </main>

      {/* Nature-inspired Agricultural Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 mt-12 py-8 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center space-x-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-800 flex items-center justify-center text-white">
              <Leaf className="w-4 h-4 text-emerald-200" />
            </div>
            <div>
              <span className="font-bold text-slate-200">CottonGuard AI</span>
              <span className="mx-2">•</span>
              <span>Smart Cotton Disease Detection & Advisory</span>
            </div>
          </div>

          <div className="flex items-center space-x-4 text-slate-400">
            <span>SAR-CLD-2024 Taxonomy</span>
            <span>•</span>
            <span>MobileNetV2 Edge Engine</span>
            <span>•</span>
            <span>7-Class Classification</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
