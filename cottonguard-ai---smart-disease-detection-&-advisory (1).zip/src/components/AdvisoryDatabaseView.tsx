import React, { useState, useMemo } from 'react';
import {
  Database,
  Search,
  Filter,
  Download,
  Trash2,
  Edit3,
  CheckCircle2,
  Clock,
  ShieldAlert,
  AlertTriangle,
  HeartHandshake,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
  MapPin,
  Calendar,
  Eye,
  X,
  FileSpreadsheet,
  Plus,
} from 'lucide-react';
import { AdvisoryRecord, CottonDiseaseClass, SeverityLevel } from '../types/cotton';
import { COTTON_CLASSES } from '../data/cottonKnowledge';

interface AdvisoryDatabaseViewProps {
  records: AdvisoryRecord[];
  onUpdateRecord: (id: string, updates: Partial<AdvisoryRecord>) => Promise<void>;
  onDeleteRecord: (id: string) => Promise<void>;
  onRefreshRecords: () => void;
  onNavigateToScanner: () => void;
}

export const AdvisoryDatabaseView: React.FC<AdvisoryDatabaseViewProps> = ({
  records,
  onUpdateRecord,
  onDeleteRecord,
  onRefreshRecords,
  onNavigateToScanner,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCondition, setSelectedCondition] = useState<string>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const [activeModalRecord, setActiveModalRecord] = useState<AdvisoryRecord | null>(null);

  // Status edit state inside modal
  const [editingStatus, setEditingStatus] = useState<AdvisoryRecord['status']>('Active Alert');
  const [editingActionNotes, setEditingActionNotes] = useState<string>('');
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchesSearch =
        searchTerm === '' ||
        r.condition.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.plotNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.fieldLocation.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.farmerNotes && r.farmerNotes.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesCondition =
        selectedCondition === 'all' || r.condition.toLowerCase() === selectedCondition.toLowerCase();

      const matchesSeverity =
        selectedSeverity === 'all' || r.severity.toLowerCase() === selectedSeverity.toLowerCase();

      const matchesStatus =
        selectedStatus === 'all' || r.status.toLowerCase() === selectedStatus.toLowerCase();

      return matchesSearch && matchesCondition && matchesSeverity && matchesStatus;
    });
  }, [records, searchTerm, selectedCondition, selectedSeverity, selectedStatus]);

  // Summary Metrics
  const metrics = useMemo(() => {
    const total = records.length;
    const critical = records.filter((r) => r.severity === 'Critical').length;
    const inTreatment = records.filter((r) => r.status === 'Treatment Scheduled').length;
    const remediated = records.filter((r) => r.status === 'Remediated').length;
    return { total, critical, inTreatment, remediated };
  }, [records]);

  // Open Details Modal
  const openRecordModal = (record: AdvisoryRecord) => {
    setActiveModalRecord(record);
    setEditingStatus(record.status);
    setEditingActionNotes(record.actionTakenNotes || '');
  };

  // Save Modal Updates
  const handleSaveModalUpdates = async () => {
    if (!activeModalRecord) return;
    setIsUpdating(true);
    await onUpdateRecord(activeModalRecord.id, {
      status: editingStatus,
      actionTakenNotes: editingActionNotes,
    });
    setActiveModalRecord((prev) =>
      prev ? { ...prev, status: editingStatus, actionTakenNotes: editingActionNotes } : null
    );
    setIsUpdating(false);
  };

  // Export to CSV
  const exportToCSV = () => {
    if (records.length === 0) {
      alert('No records available to export.');
      return;
    }

    const headers = [
      'ID',
      'Timestamp',
      'Condition',
      'Confidence %',
      'Severity',
      'Plot Number',
      'Field Location',
      'Status',
      'Farmer Notes',
      'Action Taken Notes',
      'Immediate Action Protocol',
      'Chemical Spray Protocol',
    ];

    const rows = filteredRecords.map((r) => [
      `"${r.id}"`,
      `"${new Date(r.timestamp).toLocaleString()}"`,
      `"${r.condition}"`,
      `"${(r.confidence * 100).toFixed(1)}"`,
      `"${r.severity}"`,
      `"${r.plotNumber.replace(/"/g, '""')}"`,
      `"${r.fieldLocation.replace(/"/g, '""')}"`,
      `"${r.status}"`,
      `"${(r.farmerNotes || '').replace(/"/g, '""')}"`,
      `"${(r.actionTakenNotes || '').replace(/"/g, '""')}"`,
      `"${(r.advisory?.remediation?.immediateAction?.join('; ') || '').replace(/"/g, '""')}"`,
      `"${(r.advisory?.remediation?.chemicalTreatment?.join('; ') || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `cotton_advisory_database_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getSeverityStyle = (sev: SeverityLevel) => {
    switch (sev) {
      case 'Critical':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'Moderate':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Low':
        return 'bg-indigo-100 text-indigo-800 border-indigo-300';
      case 'Healthy':
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    }
  };

  const getStatusStyle = (st: AdvisoryRecord['status']) => {
    switch (st) {
      case 'Active Alert':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'Treatment Scheduled':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Remediated':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Archived':
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
              <Database className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              Live Detected Advisory Database
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Centralized persistent storage of all live camera detections, agronomic prescriptions, and field treatment schedules.
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={exportToCSV}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onNavigateToScanner}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-700 hover:bg-emerald-600 text-white shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>New Live Scan</span>
          </button>
        </div>
      </div>

      {/* Metrics Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Total Saved Advisories</span>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">{metrics.total}</div>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs text-red-600 font-medium flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span>Critical Alerts</span>
          </span>
          <div className="text-2xl font-extrabold text-red-700 mt-1">{metrics.critical}</div>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs text-amber-600 font-medium">In Treatment</span>
          <div className="text-2xl font-extrabold text-amber-700 mt-1">{metrics.inTreatment}</div>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs text-emerald-600 font-medium">Remediated / Healthy</span>
          <div className="text-2xl font-extrabold text-emerald-700 mt-1">{metrics.remediated}</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by condition, plot, location, notes..."
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          {/* Condition Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedCondition}
              onChange={(e) => setSelectedCondition(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
            >
              <option value="all">All Pathology Classes (7)</option>
              {COTTON_CLASSES.map((cls) => (
                <option key={cls} value={cls}>
                  {cls}
                </option>
              ))}
            </select>
          </div>

          {/* Severity Filter */}
          <div className="md:col-span-2">
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
            >
              <option value="all">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="Moderate">Moderate</option>
              <option value="Low">Low</option>
              <option value="Healthy">Healthy</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="md:col-span-2">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
            >
              <option value="all">All Statuses</option>
              <option value="Active Alert">Active Alert</option>
              <option value="Treatment Scheduled">Treatment Scheduled</option>
              <option value="Remediated">Remediated</option>
              <option value="Archived">Archived</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 text-xs text-slate-500">
          <span>
            Showing <strong className="text-slate-800">{filteredRecords.length}</strong> of{' '}
            {records.length} records
          </span>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold ${
                viewMode === 'cards' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Cards
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold ${
                viewMode === 'table' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Table
            </button>
          </div>
        </div>
      </div>

      {/* Record Cards Grid */}
      {viewMode === 'cards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredRecords.length === 0 ? (
            <div className="col-span-full bg-white rounded-2xl p-12 text-center border border-slate-200">
              <p className="text-sm text-slate-500">No advisory records match the active filter criteria.</p>
            </div>
          ) : (
            filteredRecords.map((record) => (
              <div
                key={record.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group"
              >
                <div className="p-5 space-y-3">
                  {/* Card Header */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${getSeverityStyle(
                        record.severity
                      )}`}
                    >
                      {record.severity}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${getStatusStyle(
                        record.status
                      )}`}
                    >
                      {record.status}
                    </span>
                  </div>

                  {/* Thumbnail & Title */}
                  <div className="flex items-start space-x-3">
                    <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-950 shrink-0 border border-slate-200">
                      {record.imageUrl ? (
                        <img
                          src={record.imageUrl}
                          alt={record.condition}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
                          🌿
                        </div>
                      )}
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                        {record.condition}
                      </h3>
                      <div className="text-xs text-slate-500 flex items-center space-x-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span>{record.plotNumber}</span>
                      </div>
                      <div className="text-[11px] font-mono text-emerald-700 font-semibold mt-0.5">
                        {(record.confidence * 100).toFixed(1)}% Confidence
                      </div>
                    </div>
                  </div>

                  {/* Farmer Notes */}
                  {record.farmerNotes && (
                    <p className="text-xs text-slate-600 line-clamp-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                      "{record.farmerNotes}"
                    </p>
                  )}

                  {/* Remediation Preview */}
                  <div className="text-[11px] text-slate-500 pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3" />
                      <span>{new Date(record.timestamp).toLocaleDateString()}</span>
                    </span>
                    <span className="font-mono text-[10px] text-slate-400">
                      {new Date(record.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="bg-slate-50/80 px-5 py-2.5 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => openRecordModal(record)}
                    className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center space-x-1"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Full Advisory</span>
                  </button>

                  <button
                    onClick={() => onDeleteRecord(record.id)}
                    className="p-1 text-slate-400 hover:text-red-600 rounded transition-colors"
                    title="Delete Record"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Table View */}
      {viewMode === 'table' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/90 text-slate-700 uppercase font-mono tracking-wider text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Specimen</th>
                  <th className="py-3 px-4">Condition</th>
                  <th className="py-3 px-4">Confidence</th>
                  <th className="py-3 px-4">Severity</th>
                  <th className="py-3 px-4">Plot & Location</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-2.5 px-4">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-slate-900 border border-slate-200">
                        {r.imageUrl && <img src={r.imageUrl} alt="" className="w-full h-full object-cover" />}
                      </div>
                    </td>
                    <td className="py-2.5 px-4 font-bold text-slate-900">{r.condition}</td>
                    <td className="py-2.5 px-4 font-mono text-emerald-700 font-bold">
                      {(r.confidence * 100).toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold ${getSeverityStyle(r.severity)}`}>
                        {r.severity}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-600">
                      <div>{r.plotNumber}</div>
                      <div className="text-[10px] text-slate-400">{r.fieldLocation}</div>
                    </td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded-md border text-[10px] font-semibold ${getStatusStyle(r.status)}`}>
                        {r.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-500 font-mono text-[11px]">
                      {new Date(r.timestamp).toLocaleDateString()}
                    </td>
                    <td className="py-2.5 px-4 text-right space-x-1">
                      <button
                        onClick={() => openRecordModal(r)}
                        className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold"
                      >
                        Details
                      </button>
                      <button
                        onClick={() => onDeleteRecord(r.id)}
                        className="p-1 text-slate-400 hover:text-red-600 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Detail & Status Modal */}
      {activeModalRecord && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-2xl p-6 sm:p-8 space-y-5">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div>
                <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${getSeverityStyle(activeModalRecord.severity)}`}>
                  {activeModalRecord.severity}
                </span>
                <h3 className="text-xl font-extrabold text-slate-900 mt-1">
                  {activeModalRecord.condition}
                </h3>
                <p className="text-xs text-slate-500">
                  {activeModalRecord.plotNumber} • {activeModalRecord.fieldLocation}
                </p>
              </div>

              <button
                onClick={() => setActiveModalRecord(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Image & Quick Specs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="aspect-square bg-slate-950 rounded-xl overflow-hidden border border-slate-200 flex items-center justify-center">
                {activeModalRecord.imageUrl ? (
                  <img
                    src={activeModalRecord.imageUrl}
                    alt={activeModalRecord.condition}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="text-slate-500 text-xs font-mono">No Image</div>
                )}
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="font-semibold text-slate-700">Diagnosis Confidence</div>
                  <div className="text-lg font-extrabold text-emerald-800 font-mono">
                    {(activeModalRecord.confidence * 100).toFixed(1)}%
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="font-semibold text-slate-700">Logged Timestamp</div>
                  <div className="text-slate-600 font-mono mt-0.5">
                    {new Date(activeModalRecord.timestamp).toLocaleString()}
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="font-semibold text-slate-700">Farmer Scout Notes</div>
                  <div className="text-slate-600 italic mt-0.5">
                    "{activeModalRecord.farmerNotes || 'No notes provided'}"
                  </div>
                </div>
              </div>
            </div>

            {/* Prescribed Remediation */}
            <div className="space-y-3 pt-2 border-t border-slate-100 text-xs">
              <h4 className="font-bold text-slate-900 text-sm">Prescribed Agronomic Protocol</h4>
              <div className="p-3 bg-red-50/70 rounded-xl border border-red-200/80">
                <span className="font-bold text-red-900">Immediate Action: </span>
                <span className="text-red-950">{activeModalRecord.advisory?.remediation?.immediateAction?.[0]}</span>
              </div>
              <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-200/80">
                <span className="font-bold text-emerald-900">Organic Remedy: </span>
                <span className="text-emerald-950">{activeModalRecord.advisory?.remediation?.organicTreatment?.[0]}</span>
              </div>
              <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200/80">
                <span className="font-bold text-amber-900">Chemical Spray: </span>
                <span className="text-amber-950">{activeModalRecord.advisory?.remediation?.chemicalTreatment?.[0]}</span>
              </div>
            </div>

            {/* Field Remediation Status Updater */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Update Field Treatment Status
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['Active Alert', 'Treatment Scheduled', 'Remediated', 'Archived'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setEditingStatus(st)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border text-center transition-all ${
                      editingStatus === st
                        ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Action Taken / Agronomic Notes
                </label>
                <input
                  type="text"
                  value={editingActionNotes}
                  onChange={(e) => setEditingActionNotes(e.target.value)}
                  placeholder="e.g. Applied Streptocycline spray at 100ppm; next review on Friday"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 bg-white"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={handleSaveModalUpdates}
                  disabled={isUpdating}
                  className="bg-emerald-700 hover:bg-emerald-600 text-white px-4 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs disabled:opacity-50"
                >
                  {isUpdating ? 'Saving...' : 'Update Record Status'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
