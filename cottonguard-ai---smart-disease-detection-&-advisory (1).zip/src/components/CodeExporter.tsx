import React, { useState } from 'react';
import {
  FileCode2,
  Download,
  Copy,
  Check,
  Terminal,
  ExternalLink,
  BookOpen,
  Sparkles,
} from 'lucide-react';

interface CodeFileItem {
  id: string;
  name: string;
  badge: string;
  description: string;
  code: string;
}

export const CodeExporter: React.FC = () => {
  const [activeFileId, setActiveFileId] = useState<string>('cv_pipeline');
  const [copied, setCopied] = useState<boolean>(false);

  const files: CodeFileItem[] = [
    {
      id: 'cv_pipeline',
      name: 'cv_pipeline.py',
      badge: 'Live OpenCV & GLI',
      description: 'Real-time OpenCV video stream capture, Green Leaf Index (GLI) calculation, and leaf lesion contour segmentation.',
      code: `"""
cv_pipeline.py
OpenCV Live Video Stream & Computer Vision Pipeline for Cotton Leaf Preprocessing
Includes Green Leaf Index (GLI), Otsu Lesion Segmentation, and Contour Extraction.
"""

import cv2
import numpy as np

def compute_green_leaf_index(frame):
    """Computes Green Leaf Index: GLI = (2*G - R - B) / (2*G + R + B)"""
    frame_float = frame.astype(np.float32)
    b, g, r = frame_float[:, :, 0], frame_float[:, :, 1], frame_float[:, :, 2]
    denominator = (2 * g + r + b)
    denominator[denominator == 0] = 1.0  # Avoid division by zero
    gli = (2 * g - r - b) / denominator
    gli_normalized = cv2.normalize(gli, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return cv2.applyColorMap(gli_normalized, cv2.COLORMAP_JET)

def extract_leaf_contour_and_lesions(frame):
    """Segment leaf lamina and detect diseased necrosis zones using HSV color masking."""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_green = np.array([25, 40, 40])
    upper_green = np.array([85, 255, 255])
    mask = cv2.inRange(hsv, lower_green, upper_green)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    annotated = frame.copy()
    if contours:
        c = max(contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(c)
        cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(annotated, "Cotton Leaf ROI", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    return annotated

def run_live_scanner(camera_index=0):
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print(f"[!] Unable to open camera index {camera_index}")
        return

    print("[*] Live Cotton Scanner started. 'c' = snapshot, 'g' = toggle GLI, 'q' = quit.")
    show_gli = False

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        display_frame = compute_green_leaf_index(frame) if show_gli else extract_leaf_contour_and_lesions(frame)
        cv2.imshow("CottonGuard AI - Live Leaf Scanner", display_frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('g'):
            show_gli = not show_gli
        elif key == ord('c'):
            cv2.imwrite("captured_cotton_leaf.jpg", frame)
            print("[+] Snapshot saved to captured_cotton_leaf.jpg")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_live_scanner()`,
    },
    {
      id: 'model_inference',
      name: 'model_inference.py',
      badge: 'MobileNetV2 / EfficientNet',
      description: 'Preprocessing pipeline matching the 224x224 input sizing, normalization parameters, and model loading logic for fast edge inference.',
      code: `"""
model_inference.py
MobileNetV2 / EfficientNetB0 Inference Pipeline for Cotton Leaf Disease Detection
SAR-CLD-2024 (7 Classes) Transfer Learning & Fine-Tuning Pipeline
"""

import numpy as np
import tensorflow as tf
from PIL import Image
import os

CLASS_NAMES = [
    'Bacterial Blight',
    'Curl Virus',
    'Healthy Leaf',
    'Herbicide Growth Damage',
    'Leaf Hopper Jassids',
    'Leaf Redding',
    'Leaf Variegation'
]

IMG_SIZE = (224, 224)

class CottonDiseaseClassifier:
    def __init__(self, model_path: str = "models/mobilenetv2_cotton_sarcld.h5"):
        self.model_path = model_path
        self.classes = CLASS_NAMES
        self.model = self._load_or_build_model()

    def _load_or_build_model(self):
        if os.path.exists(self.model_path):
            print(f"[*] Loading trained checkpoint from: {self.model_path}")
            return tf.keras.models.load_model(self.model_path)
        else:
            print("[*] Instantiating MobileNetV2 architecture with fine-tuned top layers...")
            base_model = tf.keras.applications.MobileNetV2(
                input_shape=(224, 224, 3),
                include_top=False,
                weights='imagenet'
            )
            base_model.trainable = False
            x = tf.keras.layers.GlobalAveragePooling2D()(base_model.output)
            x = tf.keras.layers.BatchNormalization()(x)
            x = tf.keras.layers.Dropout(0.3)(x)
            x = tf.keras.layers.Dense(128, activation='relu')(x)
            outputs = tf.keras.layers.Dense(len(self.classes), activation='softmax')(x)
            return tf.keras.Model(inputs=base_model.input, outputs=outputs)

    def preprocess_image(self, image_path_or_pil):
        if isinstance(image_path_or_pil, str):
            image = Image.open(image_path_or_pil).convert('RGB')
        else:
            image = image_path_or_pil.convert('RGB')
        
        image = image.resize(IMG_SIZE, Image.Resampling.BILINEAR)
        img_array = np.array(image, dtype=np.float32)
        normalized = tf.keras.applications.mobilenet_v2.preprocess_input(img_array)
        return np.expand_dims(normalized, axis=0)

    def predict(self, image_input):
        tensor = self.preprocess_image(image_input)
        preds = self.model.predict(tensor, verbose=0)[0]
        top_idx = int(np.argmax(preds))
        confidence = float(preds[top_idx])
        predicted_class = self.classes[top_idx]

        probabilities = {
            self.classes[i]: float(preds[i]) for i in range(len(self.classes))
        }

        return {
            "predicted_class": predicted_class,
            "confidence": confidence,
            "probabilities": probabilities
        }

if __name__ == "__main__":
    classifier = CottonDiseaseClassifier()
    print("[+] Model ready. 7 SAR-CLD-2024 classes supported.")`,
    },
    {
      id: 'advisory_database',
      name: 'advisory_database.py',
      badge: 'Pathology Knowledge',
      description: 'Dictionary mapping the 7 classes to rich advisory text, symptoms, and organic & chemical remediation steps.',
      code: `"""
advisory_database.py
Cotton Disease Pathology, Symptoms, and Actionable Agronomic Remediation Database
Supports the 7 classes of SAR-CLD-2024.
"""

ADVISORY_DATABASE = {
    "Bacterial Blight": {
        "scientific_name": "Xanthomonas citri subsp. malvacearum",
        "pathogen_type": "Bacterium",
        "severity": "Critical",
        "symptoms": [
            "Angular water-soaked lesions bounded by leaf veins",
            "Lesions darken from water-soaked green to purplish-black",
            "Black arm symptoms on petiole and stem",
            "Premature defoliation"
        ],
        "immediate_action": "Cease overhead sprinkler irrigation immediately to avoid water-splash dispersal.",
        "organic_treatment": "Foliar spray with Pseudomonas fluorescens (10g/L) or 5% Neem seed kernel extract.",
        "chemical_treatment": "Streptocycline (100 ppm) + Copper Oxychloride 50 WP (2.5 g/L of water).",
        "prevention": "Acid-delinted seeds treated with Carboxin; adopt B2/B3 resistant cultivars."
    },
    "Curl Virus": {
        "scientific_name": "Cotton Leaf Curl Virus (CLCuV)",
        "pathogen_type": "Begomovirus (Whitefly Bemisia tabaci vector)",
        "severity": "Critical",
        "symptoms": [
            "Upward curling of leaf lamina and margins",
            "Thickened dark green veins",
            "Cup-shaped enations on underside of leaves",
            "Severe plant stunting and lack of square formation"
        ],
        "immediate_action": "Rogue out and destroy infected plants; install yellow sticky traps at canopy level.",
        "organic_treatment": "Azadirachtin 10,000 ppm (2.5 mL/L) with liquid soap + Beauveria bassiana (5g/L).",
        "chemical_treatment": "Flonicamid 50 WG (0.3 g/L) or Afidopyropen 50 g/L (1.0 mL/L) for whitefly control.",
        "prevention": "Sow certified resistant hybrids early in the season; weed host eradication."
    },
    "Healthy Leaf": {
        "scientific_name": "Gossypium hirsutum L.",
        "pathogen_type": "None (Healthy Foliage)",
        "severity": "Healthy",
        "symptoms": ["Uniform deep emerald lamina, intact venation, vigorous growth"],
        "immediate_action": "Routine scout check.",
        "organic_treatment": "Seaweed biostimulant (3 mL/L) or liquid compost wash.",
        "chemical_treatment": "Balanced N-P-K fertigation based on soil test.",
        "prevention": "Maintain proper plant spacing (90x60cm) and drip irrigation scheduling."
    },
    "Herbicide Growth Damage": {
        "scientific_name": "Phytotoxicity (Phenoxy / Glyphosate Drift)",
        "pathogen_type": "Abiotic Chemical Injury",
        "severity": "Moderate",
        "symptoms": [
            "Epinasty and petiole twisting",
            "Parallel foliar strapping and cupping",
            "Interveinal chlorosis and puckering"
        ],
        "immediate_action": "Cease drift source; flush root zone with fresh irrigation water.",
        "organic_treatment": "Humic acid (3 mL/L) + tender coconut water (50 mL/L) + amino acid stimulant.",
        "chemical_treatment": "19:19:19 water-soluble fertilizer (5g/L) + Zinc EDTA chelate (1g/L).",
        "prevention": "Use low-drift air induction nozzles; never spray herbicides when wind > 8 km/h."
    },
    "Leaf Hopper Jassids": {
        "scientific_name": "Amrasca biguttula biguttula (Ishida)",
        "pathogen_type": "Hemipteran Sucking Insect",
        "severity": "Moderate",
        "symptoms": [
            "Wedge-shaped marginal yellowing (hopperburn)",
            "Downward curled crispy leaf margins",
            "Pale green nymphs running sideways on lower leaf surface"
        ],
        "immediate_action": "Scout 20 leaves across canopy; ensure adequate soil moisture.",
        "organic_treatment": "5% Neem oil emulsion or Lecanicillium lecanii bio-fungicide (5 g/L).",
        "chemical_treatment": "Thiamethoxam 25 WG (0.2 g/L) or Flonicamid 50 WG (0.3 g/L).",
        "prevention": "Grow hairy/pubescent cultivars; intercrop with cowpea or border castor."
    },
    "Leaf Redding": {
        "scientific_name": "Anthocyanin Accumulation / Cold Shock / Mg Deficiency",
        "pathogen_type": "Physiological Malady",
        "severity": "Low",
        "symptoms": [
            "Interveinal reddish-purple pigment accumulation",
            "Primary veins remain green",
            "Leaves turn brittle during boll formation"
        ],
        "immediate_action": "Inspect root zone for compaction or waterlogging.",
        "organic_treatment": "Foliar Epsom salt (Magnesium Sulfate MgSO4 @ 10 g/L) spray.",
        "chemical_treatment": "Magnesium Sulfate (1%) + Urea (1.5%) foliar spray twice at 10-day intervals.",
        "prevention": "Basal application of MgSO4 (25 kg/ha) at sowing in light sandy soils."
    },
    "Leaf Variegation": {
        "scientific_name": "Plastid Somatic Mutation / Abutilon Mosaic",
        "pathogen_type": "Genetic / Mosaic Chimera",
        "severity": "Low",
        "symptoms": ["Irregular creamy-yellow mosaic patches without tissue necrosis"],
        "immediate_action": "Confirm localized chimera vs viral infection.",
        "organic_treatment": "Foliar chelated iron (Fe-EDTA 1g/L) and zinc.",
        "chemical_treatment": "No bactericide/fungicide needed; maintain balanced nutrition.",
        "prevention": "Select certified disease-free genetic seed lots."
    }
}

def get_advisory(condition: str) -> dict:
    return ADVISORY_DATABASE.get(condition, ADVISORY_DATABASE["Healthy Leaf"])`,
    },
    {
      id: 'app_py',
      name: 'app.py',
      badge: 'Streamlit Interface',
      description: 'Streamlit application featuring custom CSS injection, live camera input handler, and structured advisory panels.',
      code: `"""
app.py
Streamlit Interface: AI Smart Cotton Plant Disease Detection and Advisory System
Tailored for Farmers, Agronomists, and Researchers
Supports live camera input, snapshot inference, and structured advisory panels.
"""

import streamlit as st
from PIL import Image
import numpy as np
from model_inference import CottonDiseaseClassifier
from advisory_database import get_advisory

st.set_page_config(
    page_title="AI Smart Cotton Plant Disease Detection & Advisory",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Agri-Tech Styling
st.markdown("""
<style>
    .stApp { background-color: #f7faf8; }
    .header-box {
        background: linear-gradient(135deg, #1b4332 0%, #2d6a4f 100%);
        padding: 24px;
        border-radius: 14px;
        color: white;
        margin-bottom: 24px;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="header-box"><h1>🌿 AI Smart Cotton Disease Detection</h1><p>Real-Time Edge Inference & Immediate Agronomic Advisory</p></div>', unsafe_allow_html=True)

col1, col2 = st.columns([1, 1])

with col1:
    st.subheader("📷 Live Camera Stream & Input")
    camera_img = st.camera_input("Capture live cotton leaf frame from device camera")
    upload_img = st.file_uploader("Or upload leaf photograph (.jpg, .jpeg, .png)", type=["jpg", "jpeg", "png"])
    chosen_input = camera_img or upload_img

with col2:
    st.subheader("🔬 Diagnosis & Advisory Output")
    if chosen_input:
        image = Image.open(chosen_input)
        st.image(image, caption="Analyzed Leaf Specimen", use_container_width=True)

        classifier = CottonDiseaseClassifier()
        prediction = classifier.predict(image)
        condition = prediction["predicted_class"]
        confidence = prediction["confidence"]
        adv = get_advisory(condition)

        st.success(f"**Detected Condition: {condition}** ({confidence * 100:.2f}% Confidence)")
        st.progress(float(confidence))
        st.markdown(f"**Severity:** {adv['severity']}")
        st.error(f"**Immediate Action:** {adv['immediate_action']}")
        st.warning(f"**Chemical Spray Protocol:** {adv['chemical_treatment']}")
        st.success(f"**Organic Remediation:** {adv['organic_treatment']}")
    else:
        st.info("Align the cotton leaf within the camera viewfinder above and click 'Take Photo' for real-time analysis.")`,
    },
  ];

  const currentFile = files.find((f) => f.id === activeFileId) || files[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([currentFile.code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = currentFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
              <FileCode2 className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              Computer Vision & Python Modules
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Complete, modular production scripts for local edge inference, OpenCV video streaming, and Streamlit deployment.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopy}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-700 hover:bg-emerald-600 text-white shadow-xs transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download {currentFile.name}</span>
          </button>
        </div>
      </div>

      {/* Code Viewer Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* File Tabs Sidebar (3 cols) */}
        <div className="lg:col-span-4 space-y-2">
          {files.map((file) => (
            <button
              key={file.id}
              onClick={() => setActiveFileId(file.id)}
              className={`w-full text-left p-4 rounded-2xl border transition-all flex flex-col space-y-1.5 ${
                activeFileId === file.id
                  ? 'border-emerald-600 bg-white ring-2 ring-emerald-500/20 shadow-xs'
                  : 'border-slate-200 bg-slate-50/60 hover:bg-white text-slate-600'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-slate-900 flex items-center space-x-1.5">
                  <Terminal className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{file.name}</span>
                </span>
                <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  {file.badge}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-normal line-clamp-2">
                {file.description}
              </p>
            </button>
          ))}
        </div>

        {/* Code Content Window (8 cols) */}
        <div className="lg:col-span-8 bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col">
          {/* Editor Header */}
          <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-red-500/80" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80" />
              <span className="ml-2 font-mono text-xs text-slate-300 font-semibold">
                {currentFile.name}
              </span>
            </div>

            <span className="text-[11px] font-mono text-emerald-400 bg-slate-800 px-2 py-0.5 rounded">
              Python 3.10+ • UTF-8
            </span>
          </div>

          {/* Code Text Area */}
          <div className="p-4 sm:p-6 overflow-x-auto max-h-[560px] scrollbar-thin">
            <pre className="text-xs font-mono text-emerald-300/90 leading-relaxed">
              <code>{currentFile.code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
