import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Cpu,
  Layers,
  Award,
  CheckCircle2,
  HelpCircle,
  Zap,
  Target,
  FileText,
} from 'lucide-react';
import { SAR_CLD_DATASET_METRICS } from '../data/cottonKnowledge';
import { CottonDiseaseClass } from '../types/cotton';

export const DatasetAnalytics: React.FC = () => {
  const [selectedCell, setSelectedCell] = useState<{
    actual: CottonDiseaseClass;
    predicted: CottonDiseaseClass;
    val: number;
  } | null>(null);

  const metrics = SAR_CLD_DATASET_METRICS;
  const classes = metrics.confusionMatrix.classes;
  const matrix = metrics.confusionMatrix.matrix;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider mb-3">
            <Award className="w-3.5 h-3.5 text-emerald-400" />
            <span>SAR-CLD-2024 Multi-Seed Benchmark</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Evaluation & Model Architecture Analytics
          </h1>
          <p className="text-sm text-emerald-100/90 mt-2 leading-relaxed">
            Quantitative multi-seed experimental evaluations inspired by{' '}
            <code className="text-emerald-300 font-mono text-xs bg-slate-900/60 px-1.5 py-0.5 rounded">
              cotton-ssl-vitb16-5-seed-sar-cld.ipynb
            </code>{' '}
            and fine-tuned edge MobileNetV2 / EfficientNet architectures.
          </p>
        </div>
      </div>

      {/* High-Level Metric Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Overall Accuracy</span>
            <Target className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900 mt-2 font-mono">97.42%</div>
          <div className="text-[11px] text-emerald-700 font-semibold mt-1 flex items-center space-x-1">
            <TrendingUp className="w-3 h-3" />
            <span>+3.2% vs baseline ResNet50</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Macro Precision</span>
            <Award className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900 mt-2 font-mono">96.88%</div>
          <div className="text-[11px] text-slate-500 mt-1">Min false positive rate</div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Macro Recall</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900 mt-2 font-mono">97.15%</div>
          <div className="text-[11px] text-slate-500 mt-1">99.1% on Healthy Leaf</div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>F1-Score</span>
            <Zap className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900 mt-2 font-mono">97.01%</div>
          <div className="text-[11px] text-slate-500 mt-1">Balanced harmonic mean</div>
        </div>
      </div>

      {/* Model Benchmark Comparison Table */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-emerald-700" />
            <h3 className="text-base font-bold text-slate-900">
              Deep Learning Architecture Comparison (SAR-CLD-2024)
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">5-Seed Cross-Validated</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-mono uppercase tracking-wider text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Architecture</th>
                <th className="py-3 px-4">Accuracy</th>
                <th className="py-3 px-4">Precision</th>
                <th className="py-3 px-4">Recall</th>
                <th className="py-3 px-4">F1-Score</th>
                <th className="py-3 px-4">Latency (Edge)</th>
                <th className="py-3 px-4">Model Weight</th>
                <th className="py-3 px-4">Deployment Suitability</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {metrics.models.map((m, idx) => (
                <tr
                  key={m.modelName}
                  className={idx === 0 ? 'bg-emerald-50/50 font-medium' : 'hover:bg-slate-50/50'}
                >
                  <td className="py-3 px-4 font-bold text-slate-900 flex items-center space-x-2">
                    {idx === 0 && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                    <span>{m.modelName}</span>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-emerald-800">{m.accuracy}%</td>
                  <td className="py-3 px-4 font-mono">{m.precision}%</td>
                  <td className="py-3 px-4 font-mono">{m.recall}%</td>
                  <td className="py-3 px-4 font-mono font-semibold">{m.f1Score}%</td>
                  <td className="py-3 px-4 font-mono text-emerald-700 font-semibold">
                    {m.inferenceLatencyMs} ms
                  </td>
                  <td className="py-3 px-4 font-mono">{m.modelSizeMb} MB</td>
                  <td className="py-3 px-4">
                    {idx === 0 ? (
                      <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded text-[10px] font-bold">
                        ★ Optimal for Mobile/Browser
                      </span>
                    ) : idx === 1 ? (
                      <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px]">
                        Server / Cloud Node
                      </span>
                    ) : (
                      <span className="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded text-[10px]">
                        High-End Research GPU
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive 7x7 Confusion Matrix */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              7-Class Confusion Matrix Heatmap
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Normalized percentage matrix on SAR-CLD-2024 test split (724 verified test specimens).
            </p>
          </div>

          {selectedCell && (
            <div className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl text-xs text-emerald-900 font-medium">
              Actual: <strong>{selectedCell.actual}</strong> → Predicted:{' '}
              <strong>{selectedCell.predicted}</strong> ({selectedCell.val}%)
            </div>
          )}
        </div>

        <div className="overflow-x-auto pb-2">
          <div className="inline-block min-w-[620px]">
            <div className="grid grid-cols-8 gap-1.5 text-center text-xs">
              {/* Header corner */}
              <div className="p-2 font-mono text-[10px] text-slate-400 flex items-center justify-center font-bold">
                Actual \ Pred
              </div>
              {/* Column labels */}
              {classes.map((c, i) => (
                <div
                  key={c}
                  className="p-1 font-mono text-[10px] font-semibold text-slate-600 truncate"
                  title={c}
                >
                  C{i + 1}
                </div>
              ))}

              {/* Matrix rows */}
              {matrix.map((row, rowIdx) => {
                const actualClass = classes[rowIdx];
                return (
                  <React.Fragment key={actualClass}>
                    <div
                      className="p-2 text-left font-semibold text-[11px] text-slate-700 truncate"
                      title={actualClass}
                    >
                      C{rowIdx + 1}: {actualClass.split(' ')[0]}
                    </div>
                    {row.map((val, colIdx) => {
                      const predClass = classes[colIdx];
                      const isDiagonal = rowIdx === colIdx;
                      let bg = 'bg-slate-50 text-slate-400';
                      if (isDiagonal) {
                        bg = 'bg-emerald-600 text-white font-extrabold shadow-inner';
                      } else if (val > 1.0) {
                        bg = 'bg-amber-100 text-amber-900 font-bold';
                      } else if (val > 0.4) {
                        bg = 'bg-amber-50 text-amber-800';
                      }

                      return (
                        <button
                          key={colIdx}
                          onClick={() =>
                            setSelectedCell({ actual: actualClass, predicted: predClass, val })
                          }
                          className={`p-2 rounded-lg text-[11px] font-mono transition-transform hover:scale-105 ${bg}`}
                          title={`Actual: ${actualClass} | Predicted: ${predClass}: ${val}%`}
                        >
                          {val.toFixed(1)}%
                        </button>
                      );
                    })}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-100 gap-2">
          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded bg-emerald-600" />
              <span>Correct Classifications (&gt;96%)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded bg-amber-100" />
              <span>Inter-Class Confusion (&lt;1.5%)</span>
            </span>
          </div>

          <span className="font-mono text-[11px]">
            Mean Diagonal Accuracy: <strong>97.6%</strong>
          </span>
        </div>
      </div>
    </div>
  );
};
