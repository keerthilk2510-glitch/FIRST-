import React from 'react';
import {
  Camera,
  Database,
  BarChart3,
  FileCode2,
  Leaf,
  ShieldCheck,
  Activity,
  Cpu,
} from 'lucide-react';

export type ActiveTab = 'scanner' | 'advisory' | 'database' | 'analytics' | 'code';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  hasActiveDetection: boolean;
  databaseCount: number;
  criticalAlertsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  hasActiveDetection,
  databaseCount,
  criticalAlertsCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-emerald-900/10 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-800 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-900/20 ring-2 ring-emerald-500/20">
              <Leaf className="w-6 h-6 text-emerald-200" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-xl tracking-tight text-slate-900">
                  Cotton<span className="text-emerald-700">Guard</span>
                </span>
                <span className="px-2 py-0.5 text-xs font-semibold uppercase tracking-wider bg-emerald-100 text-emerald-800 rounded-md border border-emerald-300/60">
                  AI CV 2.0
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                SAR-CLD-2024 • MobileNetV2 Live Disease Detection & Advisory
              </p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1.5 bg-slate-100/80 p-1.5 rounded-xl border border-slate-200/80">
            <button
              onClick={() => onTabChange('scanner')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                activeTab === 'scanner'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>Live Scanner</span>
            </button>

            <button
              onClick={() => onTabChange('advisory')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all duration-200 relative ${
                activeTab === 'advisory'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Advisory Panel</span>
              {hasActiveDetection && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping absolute top-1.5 right-1.5" />
              )}
            </button>

            <button
              onClick={() => onTabChange('database')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all duration-200 relative ${
                activeTab === 'database'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Advisory DB</span>
              {databaseCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 text-[11px] font-bold bg-slate-200 text-slate-700 rounded-full group-hover:bg-slate-300">
                  {databaseCount}
                </span>
              )}
              {criticalAlertsCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-red-500 absolute -top-0.5 -right-0.5" />
              )}
            </button>

            <button
              onClick={() => onTabChange('analytics')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                activeTab === 'analytics'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>SAR-CLD Benchmark</span>
            </button>

            <button
              onClick={() => onTabChange('code')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                activeTab === 'code'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <FileCode2 className="w-4 h-4" />
              <span>CV & Code</span>
            </button>
          </nav>

          {/* Engine Status Indicators */}
          <div className="flex items-center space-x-3">
            <div className="hidden lg:flex items-center space-x-2 bg-emerald-50 border border-emerald-200/80 px-3 py-1.5 rounded-lg text-xs font-medium text-emerald-800">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <Cpu className="w-3.5 h-3.5 text-emerald-600" />
              <span>MobileNetV2 Edge 224px</span>
            </div>

            <div className="hidden sm:flex items-center space-x-1.5 bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700">
              <Activity className="w-3.5 h-3.5 text-teal-600" />
              <span>97.4% Acc</span>
            </div>
          </div>
        </div>

        {/* Mobile Tab Bar */}
        <div className="flex md:hidden overflow-x-auto py-2 space-x-1 scrollbar-none border-t border-slate-100">
          <button
            onClick={() => onTabChange('scanner')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'scanner' ? 'bg-emerald-800 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Scanner</span>
          </button>
          <button
            onClick={() => onTabChange('advisory')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'advisory' ? 'bg-emerald-800 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Advisory</span>
          </button>
          <button
            onClick={() => onTabChange('database')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'database' ? 'bg-emerald-800 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Database ({databaseCount})</span>
          </button>
          <button
            onClick={() => onTabChange('analytics')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'analytics' ? 'bg-emerald-800 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Metrics</span>
          </button>
          <button
            onClick={() => onTabChange('code')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'code' ? 'bg-emerald-800 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>Code & CV</span>
          </button>
        </div>
      </div>
    </header>
  );
};
