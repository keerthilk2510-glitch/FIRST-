import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  HeartHandshake,
  CheckCircle2,
  Calendar,
  MapPin,
  FileText,
  Volume2,
  VolumeX,
  Printer,
  Save,
  ArrowRight,
  TrendingUp,
  Percent,
  Clock,
  ExternalLink,
  ChevronRight,
  Bug,
  Sparkles,
  Droplet,
  Beaker,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CottonDiseaseClass, DetectionResult, SeverityLevel } from '../types/cotton';

interface AdvisoryPanelProps {
  detection: DetectionResult | null;
  onSaveToDatabase: (detection: DetectionResult) => Promise<boolean>;
  isSavedToDb: boolean;
  onNavigateToScanner: () => void;
  onNavigateToDatabase: () => void;
}

type RemediationTab = 'immediate' | 'organic' | 'chemical' | 'prevention';

export const AdvisoryPanel: React.FC<AdvisoryPanelProps> = ({
  detection,
  onSaveToDatabase,
  isSavedToDb,
  onNavigateToScanner,
  onNavigateToDatabase,
}) => {
  const [activeTab, setActiveTab] = useState<RemediationTab>('immediate');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  if (!detection) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs max-w-2xl mx-auto my-8">
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-50 border border-emerald-200/60 flex items-center justify-center text-emerald-700 shadow-xs">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-slate-800">
          No Detection Record Active
        </h3>
        <p className="text-sm text-slate-500 mt-2 mb-6 max-w-md mx-auto">
          Scan living foliage using the live camera scanner or upload a cotton leaf photograph to generate comprehensive agronomic advisories and pathology diagnostics.
        </p>
        <button
          onClick={onNavigateToScanner}
          className="inline-flex items-center space-x-2 bg-emerald-700 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-md transition-all"
        >
          <span>Open Live Scanner</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  const {
    condition,
    confidence,
    severity,
    symptomsIdentified,
    affectedAreaPercentage,
    pathologyNotes,
    classProbabilities,
    advisory,
    inferenceLatencyMs,
    modelEngine,
    imageUrl,
    plotNumber,
    fieldLocation,
    timestamp,
  } = detection;

  const getSeverityBadge = (level: SeverityLevel) => {
    switch (level) {
      case 'Critical':
        return {
          bg: 'bg-red-50 text-red-800 border-red-200',
          dot: 'bg-red-500',
          icon: <ShieldAlert className="w-4 h-4 text-red-600" />,
          label: 'Critical Alert',
        };
      case 'Moderate':
        return {
          bg: 'bg-amber-50 text-amber-800 border-amber-200',
          dot: 'bg-amber-500',
          icon: <AlertTriangle className="w-4 h-4 text-amber-600" />,
          label: 'Moderate Risk',
        };
      case 'Low':
        return {
          bg: 'bg-indigo-50 text-indigo-800 border-indigo-200',
          dot: 'bg-indigo-500',
          icon: <HeartHandshake className="w-4 h-4 text-indigo-600" />,
          label: 'Low / Monitor',
        };
      case 'Healthy':
      default:
        return {
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          dot: 'bg-emerald-500',
          icon: <ShieldCheck className="w-4 h-4 text-emerald-600" />,
          label: 'Healthy Canopy',
        };
    }
  };

  const badge = getSeverityBadge(severity);

  // Web Speech Text-to-Speech
  const toggleSpeech = () => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported in this browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = `
      Cotton Guard Advisory Report for ${condition}.
      Severity is ${severity}.
      Confidence level is ${(confidence * 100).toFixed(1)} percent.
      Overview: ${advisory.overview}
      Immediate field action: ${advisory.remediation.immediateAction.join('. ')}
      Recommended organic remedy: ${advisory.remediation.organicTreatment.join('. ')}
      Target chemical spray protocol: ${advisory.remediation.chemicalTreatment.join('. ')}
    `;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  // Save to Database Handler
  const handleSave = async () => {
    setIsSaving(true);
    const success = await onSaveToDatabase(detection);
    setIsSaving(false);
    if (success) {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
      });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Top Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs no-print">
        <div className="flex items-center space-x-2">
          <button
            onClick={onNavigateToScanner}
            className="text-xs font-semibold text-slate-600 hover:text-emerald-700 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            ← Back to Live Scanner
          </button>
          <span className="text-slate-300">|</span>
          <span className="text-xs text-slate-500 font-mono">
            {new Date(timestamp).toLocaleDateString()} {new Date(timestamp).toLocaleTimeString()}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* TTS Listen Button */}
          <button
            onClick={toggleSpeech}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              isSpeaking
                ? 'bg-amber-100 text-amber-900 border-amber-300'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
            title="Read advisory aloud"
          >
            {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span>{isSpeaking ? 'Stop Audio' : 'Listen Aloud'}</span>
          </button>

          {/* Print Report Button */}
          <button
            onClick={handlePrint}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>

          {/* Save to Database Button */}
          <button
            onClick={handleSave}
            disabled={isSavedToDb || isSaving}
            className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs ${
              isSavedToDb
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                : 'bg-emerald-700 hover:bg-emerald-600 text-white shadow-emerald-900/20'
            }`}
          >
            {isSavedToDb ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Saved to Database</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" />
                <span>{isSaving ? 'Logging...' : 'Upload to Advisory DB'}</span>
              </>
            )}
          </button>

          {isSavedToDb && (
            <button
              onClick={onNavigateToDatabase}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 underline ml-1"
            >
              View in DB →
            </button>
          )}
        </div>
      </div>

      {/* Main Advisory Card Header */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-md overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          {/* Left: Specimen Snapshot Visual (4 Cols) */}
          <div className="lg:col-span-4 bg-slate-950 p-6 flex flex-col justify-between text-white relative">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-mono tracking-wider uppercase text-emerald-400">
                  LEAF SPECIMEN CAPTURE
                </span>
                <span className="text-[11px] font-mono bg-slate-800 px-2 py-0.5 rounded text-slate-300">
                  {inferenceLatencyMs}ms
                </span>
              </div>

              <div className="aspect-square w-full rounded-xl overflow-hidden bg-slate-900 border border-slate-800 relative flex items-center justify-center shadow-inner">
                {imageUrl ? (
                  <img
                    src={imageUrl}
                    alt={condition}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="text-slate-500 text-xs font-mono">No Image Available</div>
                )}
                {/* Surface area overlay tag */}
                <div className="absolute bottom-2.5 right-2.5 bg-slate-950/85 backdrop-blur-md px-2.5 py-1 rounded-md border border-slate-700 text-[11px] font-mono text-emerald-300">
                  Lamina Affected: {affectedAreaPercentage}%
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-1.5 text-xs text-slate-300">
              <div className="flex items-center space-x-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-semibold text-white">{plotNumber}</span>
                <span className="text-slate-400">({fieldLocation})</span>
              </div>
              <div className="text-[11px] font-mono text-slate-400 truncate">
                Engine: {modelEngine}
              </div>
            </div>
          </div>

          {/* Right: Diagnostic Breakdown & Metrics (8 Cols) */}
          <div className="lg:col-span-8 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              {/* Badge & Class Title */}
              <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
                <div
                  className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold border ${badge.bg}`}
                >
                  <span className={`w-2 h-2 rounded-full ${badge.dot}`} />
                  {badge.icon}
                  <span>{badge.label}</span>
                </div>

                <div className="flex items-center space-x-1 text-xs text-slate-500 font-mono">
                  <span>Confidence:</span>
                  <span className="text-slate-900 font-extrabold text-sm">
                    {(confidence * 100).toFixed(1)}%
                  </span>
                </div>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {condition}
              </h2>
              <p className="text-sm font-serif italic text-emerald-800 mt-0.5">
                {advisory.scientificName} • {advisory.pathogenType}
              </p>

              {/* Confidence Progress Bar */}
              <div className="mt-4 space-y-1.5">
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-700 rounded-full ${
                      severity === 'Critical'
                        ? 'bg-red-600'
                        : severity === 'Moderate'
                        ? 'bg-amber-500'
                        : 'bg-emerald-600'
                    }`}
                    style={{ width: `${Math.min(confidence * 100, 100)}%` }}
                  />
                </div>
              </div>

              {/* Pathology Overview */}
              <p className="text-sm text-slate-600 mt-4 leading-relaxed">
                {advisory.overview}
              </p>

              {/* Observed Physical Symptoms */}
              <div className="mt-5 bg-slate-50 rounded-xl p-4 border border-slate-200/80">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                  <Bug className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Observed Foliar Symptoms</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
                  {symptomsIdentified.map((symptom, idx) => (
                    <div key={idx} className="flex items-start space-x-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                      <span>{symptom}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Economic Threshold Footnote */}
            {advisory.economicThreshold && (
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold text-slate-700">Economic Action Threshold:</span>
                <span className="text-slate-600">{advisory.economicThreshold}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 7-Class Probability Distribution Chart */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-emerald-700" />
            <h3 className="text-sm font-bold text-slate-900">
              SAR-CLD-2024 Multi-Class Softmax Probability Distribution
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-500">7 Deep Learning Classes</span>
        </div>

        <div className="space-y-3">
          {classProbabilities.map((prob) => {
            const pct = (prob.probability * 100).toFixed(1);
            const isTop = prob.className === condition;
            return (
              <div key={prob.className} className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className={isTop ? 'font-bold text-emerald-800' : 'text-slate-600'}>
                    {prob.className}
                  </span>
                  <span className={`font-mono ${isTop ? 'font-bold text-emerald-800' : 'text-slate-500'}`}>
                    {pct}%
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isTop ? 'bg-emerald-600' : 'bg-slate-300'
                    }`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Structured Agronomic Remediation Panel (Tabbed) */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-md overflow-hidden">
        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50/80 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('immediate')}
            className={`flex items-center space-x-2 px-5 py-3.5 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'immediate'
                ? 'border-emerald-700 text-emerald-800 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100'
            }`}
          >
            <ShieldAlert className="w-4 h-4 text-red-600" />
            <span>1. Immediate Field Action</span>
          </button>

          <button
            onClick={() => setActiveTab('organic')}
            className={`flex items-center space-x-2 px-5 py-3.5 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'organic'
                ? 'border-emerald-700 text-emerald-800 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100'
            }`}
          >
            <Droplet className="w-4 h-4 text-emerald-600" />
            <span>2. Organic & Biocontrol</span>
          </button>

          <button
            onClick={() => setActiveTab('chemical')}
            className={`flex items-center space-x-2 px-5 py-3.5 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'chemical'
                ? 'border-emerald-700 text-emerald-800 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100'
            }`}
          >
            <Beaker className="w-4 h-4 text-amber-600" />
            <span>3. Chemical Spray Schedule</span>
          </button>

          <button
            onClick={() => setActiveTab('prevention')}
            className={`flex items-center space-x-2 px-5 py-3.5 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'prevention'
                ? 'border-emerald-700 text-emerald-800 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-teal-600" />
            <span>4. Prevention & Cultural Practices</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 sm:p-8">
          {activeTab === 'immediate' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-red-800 font-bold text-sm">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <span>Urgent Agronomic Protocols (Next 24 - 48 Hours)</span>
              </div>
              <ul className="space-y-3">
                {advisory.remediation.immediateAction.map((action, i) => (
                  <li
                    key={i}
                    className="flex items-start space-x-3 p-3.5 bg-red-50/60 rounded-xl border border-red-200/80 text-xs text-red-950 font-medium"
                  >
                    <span className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                      {i + 1}
                    </span>
                    <span className="leading-relaxed">{action}</span>
                  </li>
                ))}
              </ul>
              {advisory.suitableWeatherConditions && (
                <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">Conducive Weather Factors: </span>
                  {advisory.suitableWeatherConditions}
                </div>
              )}
            </div>
          )}

          {activeTab === 'organic' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-emerald-800 font-bold text-sm">
                <Droplet className="w-4 h-4 text-emerald-600" />
                <span>Certified Bio-Pesticides, Botanical Extracts & Microbials</span>
              </div>
              <ul className="space-y-3">
                {advisory.remediation.organicTreatment.map((item, i) => (
                  <li
                    key={i}
                    className="flex items-start space-x-3 p-3.5 bg-emerald-50/70 rounded-xl border border-emerald-200/80 text-xs text-emerald-950 font-medium"
                  >
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                      🌱
                    </span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-xs text-slate-500 italic mt-2">
                * Safe for natural predators like ladybird beetles, spiders, and pollinators. Suitable for organic cotton certification.
              </p>
            </div>
          )}

          {activeTab === 'chemical' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-amber-900 font-bold text-sm">
                <Beaker className="w-4 h-4 text-amber-600" />
                <span>Standardized Chemical Formulations & Spray Schedule</span>
              </div>
              <ul className="space-y-3">
                {advisory.remediation.chemicalTreatment.map((item, i) => (
                  <li
                    key={i}
                    className="flex items-start space-x-3 p-3.5 bg-amber-50/60 rounded-xl border border-amber-200/80 text-xs text-amber-950 font-medium"
                  >
                    <span className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                      🧪
                    </span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
              <div className="p-3 bg-amber-100/60 rounded-xl border border-amber-300 text-xs text-amber-900">
                <span className="font-bold">Caution: </span> Always use Personal Protective Equipment (gloves, face mask). Spray during calm early morning or late evening hours to avoid chemical drift and pollinator disruption.
              </div>
            </div>
          )}

          {activeTab === 'prevention' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-teal-900 font-bold text-sm">
                <ShieldCheck className="w-4 h-4 text-teal-600" />
                <span>Long-Term Cultural & Preventive Agronomy</span>
              </div>
              <ul className="space-y-3">
                {advisory.remediation.preventionTips.map((tip, i) => (
                  <li
                    key={i}
                    className="flex items-start space-x-3 p-3.5 bg-teal-50/60 rounded-xl border border-teal-200/80 text-xs text-teal-950 font-medium"
                  >
                    <span className="w-5 h-5 rounded-full bg-teal-700 text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                      🛡️
                    </span>
                    <span className="leading-relaxed">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
