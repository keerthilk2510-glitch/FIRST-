"""
cv_pipeline.py
OpenCV Live Video Stream & Computer Vision Pipeline for Cotton Leaf Preprocessing
Includes Green Leaf Index (GLI), Otsu Lesion Segmentation, and Contour Extraction.
"""

import cv2
import numpy as np

def compute_green_leaf_index(frame):
    """Computes Green Leaf Index: GLI = (2*G - R - B) / (2*G + R + B)"""
    frame_float = frame.astype(np.float32)
    b, g, r = frame_float[:, :, 0], frame_float[:, :, 1], frame_float[:, :, 2]
    denominator = (2 * g + r + b)
    denominator[denominator == 0] = 1.0  # Avoid division by zero
    gli = (2 * g - r - b) / denominator
    gli_normalized = cv2.normalize(gli, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return cv2.applyColorMap(gli_normalized, cv2.COLORMAP_JET)

def extract_leaf_contour_and_lesions(frame):
    """Segment leaf lamina and detect diseased necrosis zones using HSV color masking."""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_green = np.array([25, 40, 40])
    upper_green = np.array([85, 255, 255])
    mask = cv2.inRange(hsv, lower_green, upper_green)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    annotated = frame.copy()
    if contours:
        c = max(contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(c)
        cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(annotated, "Cotton Leaf ROI", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    return annotated

def run_live_scanner(camera_index=0):
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print(f"[!] Unable to open camera index {camera_index}")
        return

    print("[*] Live Cotton Scanner started. 'c' = snapshot, 'g' = toggle GLI, 'q' = quit.")
    show_gli = False

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        display_frame = compute_green_leaf_index(frame) if show_gli else extract_leaf_contour_and_lesions(frame)
        cv2.imshow("CottonGuard AI - Live Leaf Scanner", display_frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('g'):
            show_gli = not show_gli
        elif key == ord('c'):
            cv2.imwrite("captured_cotton_leaf.jpg", frame)
            print("[+] Snapshot saved to captured_cotton_leaf.jpg")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_live_scanner()
