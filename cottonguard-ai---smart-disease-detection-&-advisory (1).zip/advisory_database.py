"""
advisory_database.py
Cotton Disease Pathology, Symptoms, and Actionable Agronomic Remediation Database
Supports the 7 classes of SAR-CLD-2024.
"""

ADVISORY_DATABASE = {
    "Bacterial Blight": {
        "scientific_name": "Xanthomonas citri subsp. malvacearum",
        "pathogen_type": "Bacterium",
        "severity": "Critical",
        "symptoms": [
            "Angular water-soaked lesions bounded by leaf veins",
            "Lesions darken from water-soaked green to purplish-black",
            "Black arm symptoms on petiole and stem",
            "Premature defoliation"
        ],
        "immediate_action": "Cease overhead sprinkler irrigation immediately to avoid water-splash dispersal.",
        "organic_treatment": "Foliar spray with Pseudomonas fluorescens (10g/L) or 5% Neem seed kernel extract.",
        "chemical_treatment": "Streptocycline (100 ppm) + Copper Oxychloride 50 WP (2.5 g/L of water).",
        "prevention": "Acid-delinted seeds treated with Carboxin; adopt B2/B3 resistant cultivars."
    },
    "Curl Virus": {
        "scientific_name": "Cotton Leaf Curl Virus (CLCuV)",
        "pathogen_type": "Begomovirus (Whitefly Bemisia tabaci vector)",
        "severity": "Critical",
        "symptoms": [
            "Upward curling of leaf lamina and margins",
            "Thickened dark green veins",
            "Cup-shaped enations on underside of leaves",
            "Severe plant stunting and lack of square formation"
        ],
        "immediate_action": "Rogue out and destroy infected plants; install yellow sticky traps at canopy level.",
        "organic_treatment": "Azadirachtin 10,000 ppm (2.5 mL/L) with liquid soap + Beauveria bassiana (5g/L).",
        "chemical_treatment": "Flonicamid 50 WG (0.3 g/L) or Afidopyropen 50 g/L (1.0 mL/L) for whitefly control.",
        "prevention": "Sow certified resistant hybrids early in the season; weed host eradication."
    },
    "Healthy Leaf": {
        "scientific_name": "Gossypium hirsutum L.",
        "pathogen_type": "None (Healthy Foliage)",
        "severity": "Healthy",
        "symptoms": ["Uniform deep emerald lamina, intact venation, vigorous growth"],
        "immediate_action": "Routine scout check.",
        "organic_treatment": "Seaweed biostimulant (3 mL/L) or liquid compost wash.",
        "chemical_treatment": "Balanced N-P-K fertigation based on soil test.",
        "prevention": "Maintain proper plant spacing (90x60cm) and drip irrigation scheduling."
    },
    "Herbicide Growth Damage": {
        "scientific_name": "Phytotoxicity (Phenoxy / Glyphosate Drift)",
        "pathogen_type": "Abiotic Chemical Injury",
        "severity": "Moderate",
        "symptoms": [
            "Epinasty and petiole twisting",
            "Parallel foliar strapping and cupping",
            "Interveinal chlorosis and puckering"
        ],
        "immediate_action": "Cease drift source; flush root zone with fresh irrigation water.",
        "organic_treatment": "Humic acid (3 mL/L) + tender coconut water (50 mL/L) + amino acid stimulant.",
        "chemical_treatment": "19:19:19 water-soluble fertilizer (5g/L) + Zinc EDTA chelate (1g/L).",
        "prevention": "Use low-drift air induction nozzles; never spray herbicides when wind > 8 km/h."
    },
    "Leaf Hopper Jassids": {
        "scientific_name": "Amrasca biguttula biguttula (Ishida)",
        "pathogen_type": "Hemipteran Sucking Insect",
        "severity": "Moderate",
        "symptoms": [
            "Wedge-shaped marginal yellowing (hopperburn)",
            "Downward curled crispy leaf margins",
            "Pale green nymphs running sideways on lower leaf surface"
        ],
        "immediate_action": "Scout 20 leaves across canopy; ensure adequate soil moisture.",
        "organic_treatment": "5% Neem oil emulsion or Lecanicillium lecanii bio-fungicide (5 g/L).",
        "chemical_treatment": "Thiamethoxam 25 WG (0.2 g/L) or Flonicamid 50 WG (0.3 g/L).",
        "prevention": "Grow hairy/pubescent cultivars; intercrop with cowpea or border castor."
    },
    "Leaf Redding": {
        "scientific_name": "Anthocyanin Accumulation / Cold Shock / Mg Deficiency",
        "pathogen_type": "Physiological Malady",
        "severity": "Low",
        "symptoms": [
            "Interveinal reddish-purple pigment accumulation",
            "Primary veins remain green",
            "Leaves turn brittle during boll formation"
        ],
        "immediate_action": "Inspect root zone for compaction or waterlogging.",
        "organic_treatment": "Foliar Epsom salt (Magnesium Sulfate MgSO4 @ 10 g/L) spray.",
        "chemical_treatment": "Magnesium Sulfate (1%) + Urea (1.5%) foliar spray twice at 10-day intervals.",
        "prevention": "Basal application of MgSO4 (25 kg/ha) at sowing in light sandy soils."
    },
    "Leaf Variegation": {
        "scientific_name": "Plastid Somatic Mutation / Abutilon Mosaic",
        "pathogen_type": "Genetic / Mosaic Chimera",
        "severity": "Low",
        "symptoms": ["Irregular creamy-yellow mosaic patches without tissue necrosis"],
        "immediate_action": "Confirm localized chimera vs viral infection.",
        "organic_treatment": "Foliar chelated iron (Fe-EDTA 1g/L) and zinc.",
        "chemical_treatment": "No bactericide/fungicide needed; maintain balanced nutrition.",
        "prevention": "Select certified disease-free genetic seed lots."
    }
}

def get_advisory(condition: str) -> dict:
    return ADVISORY_DATABASE.get(condition, ADVISORY_DATABASE["Healthy Leaf"])
