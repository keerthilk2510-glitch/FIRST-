"""
model_inference.py
MobileNetV2 / EfficientNetB0 Inference Pipeline for Cotton Leaf Disease Detection
SAR-CLD-2024 (7 Classes) Transfer Learning & Fine-Tuning Pipeline
"""

import numpy as np
import tensorflow as tf
from PIL import Image
import os

CLASS_NAMES = [
    'Bacterial Blight',
    'Curl Virus',
    'Healthy Leaf',
    'Herbicide Growth Damage',
    'Leaf Hopper Jassids',
    'Leaf Redding',
    'Leaf Variegation'
]

IMG_SIZE = (224, 224)

class CottonDiseaseClassifier:
    def __init__(self, model_path: str = "models/mobilenetv2_cotton_sarcld.h5"):
        self.model_path = model_path
        self.classes = CLASS_NAMES
        self.model = self._load_or_build_model()

    def _load_or_build_model(self):
        if os.path.exists(self.model_path):
            print(f"[*] Loading trained checkpoint from: {self.model_path}")
            return tf.keras.models.load_model(self.model_path)
        else:
            print("[*] Instantiating MobileNetV2 architecture with fine-tuned top layers...")
            base_model = tf.keras.applications.MobileNetV2(
                input_shape=(224, 224, 3),
                include_top=False,
                weights='imagenet'
            )
            base_model.trainable = False
            x = tf.keras.layers.GlobalAveragePooling2D()(base_model.output)
            x = tf.keras.layers.BatchNormalization()(x)
            x = tf.keras.layers.Dropout(0.3)(x)
            x = tf.keras.layers.Dense(128, activation='relu')(x)
            outputs = tf.keras.layers.Dense(len(self.classes), activation='softmax')(x)
            return tf.keras.Model(inputs=base_model.input, outputs=outputs)

    def preprocess_image(self, image_path_or_pil):
        if isinstance(image_path_or_pil, str):
            image = Image.open(image_path_or_pil).convert('RGB')
        else:
            image = image_path_or_pil.convert('RGB')
        
        image = image.resize(IMG_SIZE, Image.Resampling.BILINEAR)
        img_array = np.array(image, dtype=np.float32)
        normalized = tf.keras.applications.mobilenet_v2.preprocess_input(img_array)
        return np.expand_dims(normalized, axis=0)

    def predict(self, image_input):
        tensor = self.preprocess_image(image_input)
        preds = self.model.predict(tensor, verbose=0)[0]
        top_idx = int(np.argmax(preds))
        confidence = float(preds[top_idx])
        predicted_class = self.classes[top_idx]

        probabilities = {
            self.classes[i]: float(preds[i]) for i in range(len(self.classes))
        }

        return {
            "predicted_class": predicted_class,
            "confidence": confidence,
            "probabilities": probabilities
        }

if __name__ == "__main__":
    classifier = CottonDiseaseClassifier()
    print("[+] Model ready. 7 SAR-CLD-2024 classes supported.")
